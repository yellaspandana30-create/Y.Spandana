'use strict';

/* ---------- Data ----------
   Recipe: id, name, slot, diet (vegan | veg | nonveg), main-ingredient tag (for variety),
   kcal, protein g, carbs g, fat g, ingredients [name, base cost in ₹, grocery category], how to cook.
   Expand this list toward 50 recipes for the full brief. */
const SLOTS = ['breakfast', 'lunch', 'snack', 'dinner'];
const GOALS = {
  loss:     { k: 1700, p: 80 },
  maintain: { k: 2000, p: 65 },
  gain:     { k: 2300, p: 95 }
};

const R = (id, n, s, d, t, k, p, c, f, ing, how) => ({ id, n, s, d, t, k, p, c, f, ing, how });

const RECIPES = [
  // Breakfast
  R(1, 'Egg Bhurji & Roti', 'breakfast', 'nonveg', 'egg', 410, 22, 40, 18,
    [['Eggs (3)', 21, 'Protein'], ['Wheat flour', 4, 'Grains'], ['Onion & tomato', 5, 'Vegetables'], ['Oil', 3, 'Pantry']],
    'Fry chopped onion and tomato, add beaten eggs and scramble. Knead dough, roll and toast rotis on a tawa.'),
  R(2, 'Poha with Peanuts', 'breakfast', 'vegan', 'poha', 355, 9, 55, 11,
    [['Poha', 8, 'Grains'], ['Peanuts', 6, 'Protein'], ['Onion', 3, 'Vegetables'], ['Oil', 2, 'Pantry']],
    'Rinse poha. Fry peanuts and onion, add turmeric and salt, mix in poha and steam 2 minutes.'),
  R(3, 'Oats & Banana Bowl', 'breakfast', 'veg', 'oats', 370, 14, 58, 9,
    [['Oats', 12, 'Grains'], ['Banana', 5, 'Fruit'], ['Milk', 10, 'Dairy']],
    'Boil oats in milk for 3 minutes in a kettle or pan. Top with sliced banana.'),
  R(4, 'Besan Chilla', 'breakfast', 'vegan', 'besan', 305, 16, 38, 10,
    [['Besan (gram flour)', 9, 'Grains'], ['Onion & chilli', 4, 'Vegetables'], ['Oil', 2, 'Pantry']],
    'Mix besan, water, onion, chilli and salt into a batter. Spread on a hot tawa and cook both sides.'),
  R(5, 'Peanut Butter Toast', 'breakfast', 'vegan', 'peanut', 405, 14, 42, 20,
    [['Bread', 8, 'Grains'], ['Peanut butter', 12, 'Protein']],
    'Toast four slices on a tawa and spread peanut butter. No cooking needed.'),
  R(6, 'Paneer Bhurji & Roti', 'breakfast', 'veg', 'paneer', 465, 24, 38, 24,
    [['Paneer', 30, 'Dairy'], ['Wheat flour', 4, 'Grains'], ['Onion & tomato', 5, 'Vegetables'], ['Oil', 3, 'Pantry']],
    'Crumble paneer into fried onion and tomato with spices. Serve with tawa rotis.'),
  R(7, 'Vegetable Upma', 'breakfast', 'vegan', 'rava', 340, 8, 52, 11,
    [['Rava (semolina)', 7, 'Grains'], ['Mixed vegetables', 6, 'Vegetables'], ['Oil', 3, 'Pantry']],
    'Roast rava, fry vegetables, add 2 cups hot water and stir the rava in until fluffy.'),

  // Lunch
  R(8, 'Soya Chunks Curry & Rice', 'lunch', 'vegan', 'soya', 630, 38, 90, 13,
    [['Soya chunks', 14, 'Protein'], ['Rice', 10, 'Grains'], ['Onion & tomato', 6, 'Vegetables'], ['Oil', 3, 'Pantry']],
    'Soak soya in hot water, squeeze dry. Cook in onion-tomato masala for 10 minutes. Serve with rice from a cooker.'),
  R(9, 'Dal Tadka & Rice', 'lunch', 'vegan', 'dal', 545, 22, 92, 10,
    [['Toor dal', 12, 'Protein'], ['Rice', 10, 'Grains'], ['Onion & tomato', 5, 'Vegetables'], ['Oil', 3, 'Pantry']],
    'Pressure-cook dal with turmeric. Temper with cumin, garlic and onion. Cook rice alongside.'),
  R(10, 'Rajma Chawal', 'lunch', 'vegan', 'rajma', 585, 24, 100, 10,
    [['Rajma', 16, 'Protein'], ['Rice', 10, 'Grains'], ['Onion & tomato', 6, 'Vegetables'], ['Oil', 3, 'Pantry']],
    'Soak rajma overnight and pressure-cook. Simmer in onion-tomato gravy. Serve over rice.'),
  R(11, 'Egg Curry & Rice', 'lunch', 'nonveg', 'egg', 625, 26, 85, 20,
    [['Eggs (3)', 21, 'Protein'], ['Rice', 10, 'Grains'], ['Onion & tomato', 6, 'Vegetables'], ['Oil', 4, 'Pantry']],
    'Boil eggs and peel. Simmer in spiced onion-tomato gravy for 8 minutes. Serve with rice.'),
  R(12, 'Chole & Roti', 'lunch', 'vegan', 'chana', 575, 24, 88, 14,
    [['Kabuli chana', 14, 'Protein'], ['Wheat flour', 6, 'Grains'], ['Onion & tomato', 6, 'Vegetables'], ['Oil', 3, 'Pantry']],
    'Soak chana overnight, pressure-cook, then simmer in masala. Serve with rotis.'),
  R(13, 'Paneer Curry & Roti', 'lunch', 'veg', 'paneer', 665, 30, 60, 34,
    [['Paneer', 35, 'Dairy'], ['Wheat flour', 6, 'Grains'], ['Onion & tomato', 6, 'Vegetables'], ['Oil', 4, 'Pantry']],
    'Cube paneer and simmer in tomato-onion gravy for 5 minutes. Serve with rotis.'),
  R(14, 'Chicken Curry & Rice', 'lunch', 'nonveg', 'chicken', 670, 42, 80, 20,
    [['Chicken (150g)', 35, 'Protein'], ['Rice', 10, 'Grains'], ['Onion & tomato', 6, 'Vegetables'], ['Oil', 4, 'Pantry']],
    'Fry onion, add chicken and spices, cover and cook 20 minutes. Serve with rice.'),

  // Snack
  R(15, 'Roasted Chana & Tea', 'snack', 'veg', 'chana', 215, 12, 30, 5,
    [['Roasted chana', 8, 'Protein'], ['Milk tea', 5, 'Dairy']],
    'Brew tea in a kettle. Eat roasted chana straight from the packet.'),
  R(16, 'Peanuts & Banana', 'snack', 'vegan', 'peanut', 285, 10, 32, 13,
    [['Peanuts', 10, 'Protein'], ['Banana', 5, 'Fruit']],
    'No cooking. Dry-roast peanuts on a tawa for extra crunch.'),
  R(17, 'Curd with Banana', 'snack', 'veg', 'curd', 190, 8, 26, 6,
    [['Curd', 12, 'Dairy'], ['Banana', 5, 'Fruit']],
    'Slice banana into curd and add a pinch of salt or sugar.'),
  R(18, 'Boiled Eggs & Salad', 'snack', 'nonveg', 'egg', 215, 14, 6, 15,
    [['Eggs (2)', 14, 'Protein'], ['Cucumber', 4, 'Vegetables']],
    'Boil eggs for 10 minutes. Slice cucumber and add salt and pepper.'),
  R(19, 'Sprouts Chaat', 'snack', 'vegan', 'moong', 210, 14, 32, 3,
    [['Moong sprouts', 8, 'Protein'], ['Onion, tomato, lemon', 4, 'Vegetables']],
    'Soak moong overnight, drain and cover in a cloth for a day to sprout. Mix with onion, tomato and lemon.'),
  R(20, 'Banana Milkshake', 'snack', 'veg', 'milk', 260, 9, 40, 7,
    [['Bananas (2)', 10, 'Fruit'], ['Milk', 12, 'Dairy']],
    'Mash bananas into cold milk and shake in a bottle.'),

  // Dinner
  R(21, 'Dal Khichdi & Curd', 'dinner', 'veg', 'dal', 540, 22, 85, 12,
    [['Moong dal', 7, 'Protein'], ['Rice', 8, 'Grains'], ['Curd', 10, 'Dairy'], ['Ghee / oil', 3, 'Pantry']],
    'Cook rice and moong dal together with turmeric and salt until soft. Serve with curd.'),
  R(22, 'Veg Pulao & Curd', 'dinner', 'veg', 'curd', 510, 14, 82, 14,
    [['Rice', 10, 'Grains'], ['Mixed vegetables', 8, 'Vegetables'], ['Curd', 10, 'Dairy'], ['Oil', 3, 'Pantry']],
    'Fry vegetables and whole spices, add rice and water, cook in a cooker for 2 whistles.'),
  R(23, 'Masoor Dal & Roti', 'dinner', 'vegan', 'dal', 490, 22, 80, 9,
    [['Wheat flour', 6, 'Grains'], ['Masoor dal', 10, 'Protein'], ['Onion & tomato', 5, 'Vegetables'], ['Oil', 3, 'Pantry']],
    'Masoor dal cooks in 15 minutes without soaking. Temper and serve with rotis.'),
  R(24, 'Soya Pulao', 'dinner', 'vegan', 'soya', 550, 30, 80, 12,
    [['Soya chunks', 14, 'Protein'], ['Rice', 10, 'Grains'], ['Mixed vegetables', 6, 'Vegetables'], ['Oil', 3, 'Pantry']],
    'Soak soya, fry with vegetables and spices, add rice and water and cook in a cooker.'),
  R(25, 'Egg Fried Rice', 'dinner', 'nonveg', 'egg', 560, 22, 78, 18,
    [['Eggs (2)', 14, 'Protein'], ['Rice', 10, 'Grains'], ['Mixed vegetables', 6, 'Vegetables'], ['Oil', 4, 'Pantry']],
    'Scramble eggs in a pan, add leftover or fresh rice and chopped vegetables, toss on high heat.'),
  R(26, 'Palak Paneer & Roti', 'dinner', 'veg', 'paneer', 590, 28, 52, 30,
    [['Paneer', 30, 'Dairy'], ['Spinach', 8, 'Vegetables'], ['Wheat flour', 6, 'Grains'], ['Oil', 3, 'Pantry']],
    'Blanch and blend spinach, simmer with paneer cubes and spices. Serve with rotis.'),
  R(27, 'Chicken Masala & Roti', 'dinner', 'nonveg', 'chicken', 600, 40, 55, 24,
    [['Chicken (150g)', 35, 'Protein'], ['Wheat flour', 6, 'Grains'], ['Onion & tomato', 6, 'Vegetables'], ['Oil', 4, 'Pantry']],
    'Marinate chicken with curd and spices, cook covered for 20 minutes. Serve with rotis.')
];

/* ---------- State ---------- */
const $ = id => document.getElementById(id);
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
let S = { budget: 120, diet: 'veg', goal: 'gain', adj: 100, plan: null };
let charts = [];

const allowed = r => S.diet === 'nonveg' || (S.diet === 'veg' && r.d !== 'nonveg') || r.d === 'vegan';
const ip = i => Math.round(i[1] * S.adj / 100);               // ingredient price after slider
const price = r => r.ing.reduce((sum, i) => sum + ip(i), 0);  // meal price
const byId = id => RECIPES.find(r => r.id === id);
const pool = slot => RECIPES.filter(r => r.s === slot && allowed(r));
const sumOf = list => list.reduce((t, r) => ({ k: t.k + r.k, p: t.p + r.p, c: t.c + r.c, f: t.f + r.f, cost: t.cost + price(r) }),
                                  { k: 0, p: 0, c: 0, f: 0, cost: 0 });

/* ---------- Optimizer ----------
   Multiple-choice knapsack: pick exactly one meal per slot, total cost <= budget,
   maximizing a score for protein and calorie targets with a penalty for repeating the same main ingredient.
   Only ~1,500 combinations, so it is searched exhaustively (exact, not greedy). */
function score(list) {
  const T = GOALS[S.goal], tot = sumOf(list);
  const repeats = list.length - new Set(list.map(r => r.t)).size;
  return Math.min(tot.p / T.p, 1.1) * 50
       + (1 - Math.min(1, Math.abs(tot.k - T.k) / T.k)) * 40
       - repeats * 12
       + Math.random() * 4;                       // small jitter so each click can vary
}

function generate() {
  const pools = SLOTS.map(pool);
  const cheapest = pools.reduce((a, p) => a + Math.min(...p.map(price)), 0);
  if (cheapest > S.budget) {
    S.plan = null;
    $('result').hidden = true;
    setStatus(`₹${S.budget} is too low for four meals. The cheapest plan for this diet costs ₹${cheapest}.`, true);
    return;
  }
  let best = null;
  (function walk(i, pick, cost) {
    if (cost > S.budget) return;
    if (i === SLOTS.length) {
      const sc = score(pick);
      if (!best || sc > best.sc) best = { sc, pick: [...pick] };
      return;
    }
    for (const r of pools[i]) { pick.push(r); walk(i + 1, pick, cost + price(r)); pick.pop(); }
  })(0, [], 0);

  S.plan = {};
  best.pick.forEach(r => { S.plan[r.s] = r.id; });
  setStatus('');
  render();
}

/* ---------- Swap ---------- */
function swap(slot) {
  const current = byId(S.plan[slot]);
  const others = SLOTS.filter(s => s !== slot).reduce((a, s) => a + price(byId(S.plan[s])), 0);
  const room = S.budget - others;
  const T = GOALS[S.goal];
  const options = pool(slot)
    .filter(r => r.id !== current.id && price(r) <= room)
    .map(r => ({ r, d: Math.abs(r.k - current.k) / current.k + Math.abs(r.p - current.p) / Math.max(current.p, 1) + Math.abs(price(r) - price(current)) / S.budget }))
    .sort((a, b) => a.d - b.d);
  if (!options.length) { setStatus(`No other ${slot} option fits your budget and diet.`, true); return; }
  const choice = options[Math.floor(Math.random() * Math.min(2, options.length))].r;
  S.plan[slot] = choice.id;
  setStatus(`Swapped ${slot} to ${choice.n}.`);
  render();
}

/* ---------- Rendering ---------- */
function setStatus(msg, isError) {
  const el = $('status');
  el.textContent = msg;
  el.className = isError ? 'error' : '';
}

function targets() {
  const T = GOALS[S.goal];
  const f = Math.round(T.k * 0.25 / 9);
  const c = Math.round((T.k - T.p * 4 - f * 9) / 4);
  return { k: T.k, p: T.p, c, f };
}

function render() {
  const meals = SLOTS.map(s => byId(S.plan[s]));
  const tot = sumOf(meals);
  const T = targets();

  $('result').hidden = false;
  $('sKcal').textContent = `${tot.k} / ${T.k}`;
  $('sProt').textContent = `${tot.p}g / ${T.p}g`;
  $('meterText').textContent = `₹${tot.cost} of ₹${S.budget} spent, ₹${S.budget - tot.cost} left`;
  $('meterFill').style.width = Math.min(100, tot.cost / S.budget * 100) + '%';

  $('meals').innerHTML = meals.map(r => `
    <article class="meal">
      <div class="meal-head"><h3>${r.s}</h3><span class="badge">₹${price(r)}</span></div>
      <h4>${r.n}</h4>
      <p class="macros">${r.k} kcal, ${r.p}g protein, ${r.c}g carbs, ${r.f}g fat</p>
      <p class="breakdown">${r.ing.map(i => `${i[0]} ₹${ip(i)}`).join(' + ')} = ₹${price(r)}</p>
      <details><summary>How to cook</summary><p>${r.how}</p></details>
      <button type="button" class="swap" data-slot="${r.s}">Swap ${r.s}</button>
    </article>`).join('');

  drawCharts(tot, T);
  renderGrocery(meals);
  save();
}

function drawCharts(tot, T) {
  charts.forEach(c => c.destroy());
  charts = [];
  if (typeof Chart === 'undefined') {
    $('chartNote').textContent = 'Charts need an internet connection to load Chart.js.';
    return;
  }
  $('chartNote').textContent = 'Protein, carbs and fat in grams, compared with your daily targets.';
  const make = (id, title, d) => new Chart($(id), {
    type: 'doughnut',
    data: { labels: ['Protein', 'Carbs', 'Fat'], datasets: [{ data: d, backgroundColor: ['#0e6e5c', '#f2b632', '#c2372a'] }] },
    options: { plugins: { title: { display: true, text: title }, legend: { position: 'bottom' } } }
  });
  charts.push(make('planChart', 'Your plan (g)', [tot.p, tot.c, tot.f]));
  charts.push(make('targetChart', 'Daily target (g)', [T.p, T.c, T.f]));
}

function renderGrocery(meals) {
  const items = {};
  meals.forEach(r => r.ing.forEach(i => {
    const o = items[i[0]] || (items[i[0]] = { cat: i[2], cost: 0 });
    o.cost += ip(i) * 7 * 0.9;                    // weekly quantity at ~10% bulk discount
  }));
  const groups = {};
  let total = 0;
  Object.entries(items).forEach(([name, o]) => {
    const cost = Math.round(o.cost);
    total += cost;
    (groups[o.cat] = groups[o.cat] || []).push([name, cost]);
  });
  $('groceryTotal').textContent = `Estimated bulk price for 7 days of this plan: ₹${total}`;
  $('grocery').innerHTML = Object.keys(groups).sort().map(cat => `
    <div><h3>${cat}</h3><ul>${groups[cat].map(([n, c]) => `<li><span>${n}</span><span>₹${c}</span></li>`).join('')}</ul></div>`).join('');
}

/* ---------- Persistence ---------- */
function save() {
  try { localStorage.setItem('platepilot', JSON.stringify(S)); } catch (e) { /* storage unavailable */ }
}
function load() {
  try {
    const saved = JSON.parse(localStorage.getItem('platepilot'));
    if (saved) S = Object.assign(S, saved);
  } catch (e) { /* ignore corrupt data */ }
  $('budget').value = S.budget;
  $('diet').value = S.diet;
  $('goal').value = S.goal;
  $('adj').value = S.adj;
  $('adjOut').textContent = S.adj + '%';
  if (S.plan && SLOTS.every(s => byId(S.plan[s]))) render();
}

/* ---------- Events ---------- */
$('profile').addEventListener('submit', e => {
  e.preventDefault();
  const b = Number($('budget').value);
  if (!b || b < 50 || b > 500) { setStatus('Enter a daily budget between ₹50 and ₹500.', true); return; }
  S.budget = b;
  S.diet = $('diet').value;
  S.goal = $('goal').value;
  S.adj = Number($('adj').value);
  generate();
});
$('adj').addEventListener('input', e => { $('adjOut').textContent = e.target.value + '%'; });
$('meals').addEventListener('click', e => {
  const btn = e.target.closest('.swap');
  if (btn) swap(btn.dataset.slot);
});

load();
