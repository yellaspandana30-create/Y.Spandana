'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const v = require('../src/validate');

const good = { budget: 120, diet: 'veg', goal: 'gain', adj: 100 };

test('accepts a valid profile and normalises numeric strings', () => {
  assert.deepEqual(v.validateProfile(good).value, good);
  assert.equal(v.validateProfile({ ...good, budget: ' 150 ', adj: '110' }).value.budget, 150);
});

test('adj defaults to 100 when omitted', () => {
  assert.equal(v.validateProfile({ budget: 100, diet: 'vegan', goal: 'loss' }).value.adj, 100);
});

test('rejects out-of-range, fractional and non-numeric budgets', () => {
  for (const budget of [49, 501, -5, 99.5, NaN, Infinity, '', 'abc', '1e3', null, undefined, {}, [], true]) {
    const r = v.validateProfile({ ...good, budget });
    assert.equal(r.ok, false, String(budget));
    assert.ok(r.errors.budget, String(budget));
  }
});

test('rejects unknown diet and goal, including prototype keys', () => {
  for (const diet of ['keto', '', 5, null, 'VEG']) assert.ok(v.validateProfile({ ...good, diet }).errors.diet);
  for (const goal of ['bulk', 'constructor', '__proto__', 'toString', 7]) assert.ok(v.validateProfile({ ...good, goal }).errors.goal, String(goal));
});

test('rejects adj outside 80..130', () => {
  for (const adj of [79, 131, 'x', 1.5, null]) assert.ok(v.validateProfile({ ...good, adj }).errors.adj, String(adj));
});

test('reports every bad field at once', () => {
  const r = v.validateProfile({ budget: 1, diet: 'x', goal: 'y', adj: 0 });
  assert.deepEqual(Object.keys(r.errors).sort(), ['adj', 'budget', 'diet', 'goal']);
});

test('rejects non-object bodies', () => {
  for (const b of [null, undefined, 'text', 5, [], [good]]) assert.equal(v.validateProfile(b).ok, false);
});

test('ignores extra fields (they never reach the database)', () => {
  assert.deepEqual(v.validateProfile({ ...good, admin: true, sql: "'; DROP TABLE plans;--" }).value, good);
});

test('slot and id validation', () => {
  assert.equal(v.validateSlot({ slot: 'lunch' }).ok, true);
  for (const b of [{ slot: 'brunch' }, { slot: 1 }, {}, null]) assert.equal(v.validateSlot(b).ok, false);
  assert.equal(v.validateId('12').value, 12);
  for (const id of ['0', '-1', '1.5', 'abc', '', '1; DROP TABLE plans', undefined]) assert.equal(v.validateId(id).ok, false, String(id));
});

test('recipe filter validation', () => {
  assert.equal(v.validateRecipeFilter({}).ok, true);
  assert.equal(v.validateRecipeFilter({ diet: 'vegan', slot: 'snack' }).ok, true);
  assert.equal(v.validateRecipeFilter({ diet: 'x' }).ok, false);
  assert.equal(v.validateRecipeFilter({ slot: 'x' }).ok, false);
});
