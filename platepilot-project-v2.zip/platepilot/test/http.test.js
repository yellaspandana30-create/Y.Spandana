'use strict';
/* End-to-end tests through real HTTP. They need Express, so they are skipped until `npm install` has run. */
const test = require('node:test');
const assert = require('node:assert/strict');

let createApp; try { ({ createApp } = require('../src/app')); } catch { createApp = null; }
const { openDb } = require('../src/db');
const skip = createApp ? false : 'express is not installed (run npm install)';

async function withServer(fn, options) {
  const server = createApp(openDb(), options).listen(0);
  const base = `http://127.0.0.1:${server.address().port}`;
  try { await fn(base); } finally { server.close(); }
}
const post = (url, body) => fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: typeof body === 'string' ? body : JSON.stringify(body) });

test('serves the single-page app and security headers', { skip }, () => withServer(async base => {
  const res = await fetch(base + '/');
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-security-policy'), /default-src 'self'/);
  assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(res.headers.get('x-powered-by'), null);
  assert.match(await res.text(), /PlatePilot/);
}));

test('full flow: create plan, fetch, swap, grocery list', { skip }, () => withServer(async base => {
  const created = await post(base + '/api/plans', { budget: 120, diet: 'veg', goal: 'gain', adj: 100 });
  assert.equal(created.status, 201);
  const plan = await created.json();
  assert.ok(plan.totals.cost <= 120);
  assert.equal((await (await fetch(`${base}/api/plans/${plan.id}`)).json()).id, plan.id);
  const swapped = await post(`${base}/api/plans/${plan.id}/swap`, { slot: 'lunch' });
  assert.equal(swapped.status, 200);
  const grocery = await (await fetch(`${base}/api/plans/${plan.id}/grocery`)).json();
  assert.ok(grocery.total > 0);
}));

test('bad input and bad JSON return clean 400s', { skip }, () => withServer(async base => {
  const bad = await post(base + '/api/plans', { budget: 'x', diet: 'veg', goal: 'gain' });
  assert.equal(bad.status, 400);
  assert.ok((await bad.json()).fields.budget);
  const broken = await post(base + '/api/plans', '{not json');
  assert.equal(broken.status, 400);
  assert.match((await broken.json()).error, /JSON/);
}));

test('unknown API routes return JSON 404 and oversized bodies 413', { skip }, () => withServer(async base => {
  const nf = await fetch(base + '/api/nope');
  assert.equal(nf.status, 404);
  assert.ok((await nf.json()).error);
  const big = await post(base + '/api/plans', JSON.stringify({ budget: 120, pad: 'x'.repeat(20000) }));
  assert.equal(big.status, 413);
}));

test('rate limiting kicks in with 429', { skip }, () => withServer(async base => {
  let last;
  for (let i = 0; i < 6; i++) last = await fetch(base + '/api/health');
  assert.equal(last.status, 429);
}, { rateLimit: { max: 5 } }));
