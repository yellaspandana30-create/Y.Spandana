'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { openDb } = require('../src/db');
const { createController } = require('../src/controllers');

const make = () => createController(openDb(), { rng: () => 0 });
const good = { budget: 120, diet: 'veg', goal: 'gain', adj: 100 };

test('health reports the recipe count', () => {
  const r = make().health();
  assert.equal(r.status, 200);
  assert.ok(r.body.recipes >= 50);
});

test('createPlan returns 201 with a complete, in-budget plan', () => {
  const r = make().createPlan(good);
  assert.equal(r.status, 201);
  const p = r.body;
  assert.equal(p.meals.length, 4);
  assert.ok(p.totals.cost <= 120);
  assert.equal(p.remaining, 120 - p.totals.cost);
  assert.equal(p.targets.protein, 95);
  for (const m of p.meals) {
    assert.equal(m.recipe.price, m.recipe.ingredients.reduce((a, i) => a + i.cost, 0));
  }
});

test('createPlan: invalid input gives 400 with per-field messages', () => {
  const r = make().createPlan({ budget: 'lots', diet: 'veg', goal: 'gain' });
  assert.equal(r.status, 400);
  assert.ok(r.body.fields.budget);
});

test('createPlan: infeasible budget gives 422 and a helpful message', () => {
  const r = make().createPlan({ ...good, budget: 50 });
  assert.equal(r.status, 422);
  assert.match(r.body.error, /too low/);
});

test('price slider changes plan costs', () => {
  const c = make();
  const cheap = c.createPlan({ ...good, budget: 300, adj: 80 }).body;
  const dear = c.createPlan({ ...good, budget: 300, adj: 130 }).body;
  assert.equal(cheap.profile.adj, 80);
  assert.ok(cheap.totals.cost < dear.totals.cost);
});

test('getPlan returns the stored plan, 404 when missing, 400 for a bad id', () => {
  const c = make();
  const id = c.createPlan(good).body.id;
  assert.equal(c.getPlan(id).body.id, id);
  assert.equal(c.getPlan('999').status, 404);
  assert.equal(c.getPlan('abc').status, 400);
});

test('swap changes only the requested slot, stays in budget and is saved', () => {
  const c = make();
  const before = c.createPlan({ ...good, budget: 150 }).body;
  const r = c.swapMeal(before.id, { slot: 'dinner' });
  assert.equal(r.status, 200);
  assert.match(r.body.message, /Swapped dinner/);
  assert.notEqual(r.body.meals[3].recipe.id, before.meals[3].recipe.id);
  for (const i of [0, 1, 2]) assert.equal(r.body.meals[i].recipe.id, before.meals[i].recipe.id);
  assert.ok(r.body.totals.cost <= 150);
  assert.equal(c.getPlan(before.id).body.meals[3].recipe.id, r.body.meals[3].recipe.id);
});

test('swap validation: bad slot 400, missing plan 404', () => {
  const c = make();
  const id = c.createPlan(good).body.id;
  assert.equal(c.swapMeal(id, { slot: 'elevenses' }).status, 400);
  assert.equal(c.swapMeal(id, undefined).status, 400);
  assert.equal(c.swapMeal(999, { slot: 'lunch' }).status, 404);
});

test('grocery list is built from the stored plan', () => {
  const c = make();
  const id = c.createPlan(good).body.id;
  const g = c.getGrocery(id);
  assert.equal(g.status, 200);
  assert.ok(g.body.total > 0);
  assert.ok(g.body.categories.length >= 3);
  assert.equal(c.getGrocery(999).status, 404);
});

test('listRecipes filters by diet and slot and validates the filter', () => {
  const c = make();
  const vegan = c.listRecipes({ diet: 'vegan', slot: 'lunch' });
  assert.ok(vegan.body.recipes.length >= 3 && vegan.body.recipes.every(r => r.diet === 'vegan' && r.slot === 'lunch'));
  assert.equal(c.listRecipes({ diet: 'x' }).status, 400);
  assert.ok(c.listRecipes({}).body.count >= 50);
});

test('history lists recent plans; delete removes one', () => {
  const c = make();
  const a = c.createPlan(good).body.id;
  c.createPlan(good);
  assert.equal(c.listPlans().body.plans.length, 2);
  assert.equal(c.deletePlan(a).status, 200);
  assert.equal(c.deletePlan(a).status, 404);
  assert.equal(c.listPlans().body.plans.length, 1);
});
