'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { RECIPES } = require('../src/recipes');
const { SLOTS, DIETS, GOALS } = require('../src/config');
const opt = require('../src/optimizer');

const noNoise = () => 0;
const base = { budget: 120, diet: 'veg', goal: 'gain', adj: 100 };

test('plan has exactly one meal per slot, in order', () => {
  const { meals } = opt.generatePlan(RECIPES, base, noNoise);
  assert.deepEqual(meals.map(m => m.slot), SLOTS);
});

test('plan never exceeds the budget (all diets, goals, budgets, price adjustments)', () => {
  for (const diet of DIETS) for (const goal of Object.keys(GOALS)) for (const adj of [80, 100, 130]) {
    for (const budget of [90, 120, 200, 500]) {
      const r = opt.generatePlan(RECIPES, { budget, diet, goal, adj }, noNoise);
      if (r.error) continue;
      assert.ok(opt.totalsOf(r.meals, adj).cost <= budget, `${diet}/${goal}/${adj}/${budget}`);
    }
  }
});

test('respects the diet: veg has no meat/egg, vegan has no dairy-based recipes', () => {
  const veg = opt.generatePlan(RECIPES, { ...base, diet: 'veg' }, noNoise).meals;
  assert.ok(veg.every(m => m.diet !== 'nonveg'));
  const vegan = opt.generatePlan(RECIPES, { ...base, diet: 'vegan' }, noNoise).meals;
  assert.ok(vegan.every(m => m.diet === 'vegan'));
});

test('result is optimal: no other combination within budget scores higher', () => {
  const params = { budget: 130, diet: 'vegan', goal: 'maintain', adj: 100 };
  const chosen = opt.generatePlan(RECIPES, params, noNoise).meals;
  const chosenScore = opt.scorePlan(chosen, params.goal, params.adj);
  const pools = SLOTS.map(s => opt.poolFor(RECIPES, s, params.diet));
  let best = -Infinity;
  for (const a of pools[0]) for (const b of pools[1]) for (const c of pools[2]) for (const d of pools[3]) {
    const combo = [a, b, c, d];
    if (opt.totalsOf(combo, params.adj).cost <= params.budget) best = Math.max(best, opt.scorePlan(combo, params.goal, params.adj));
  }
  assert.ok(Math.abs(chosenScore - best) < 1e-9);
});

test('a higher-calorie goal gets at least as much protein as weight loss', () => {
  const gain = opt.totalsOf(opt.generatePlan(RECIPES, { ...base, goal: 'gain', budget: 250 }, noNoise).meals, 100);
  const loss = opt.totalsOf(opt.generatePlan(RECIPES, { ...base, goal: 'loss', budget: 250 }, noNoise).meals, 100);
  assert.ok(gain.protein >= loss.protein);
});

test('too-low budget returns an error with the cheapest feasible cost', () => {
  const r = opt.generatePlan(RECIPES, { ...base, budget: 50 }, noNoise);
  assert.ok(r.error);
  assert.ok(r.cheapest > 50);
  // and that cheapest cost really is achievable
  assert.ok(!opt.generatePlan(RECIPES, { ...base, budget: r.cheapest }, noNoise).error);
});

test('price slider scales costs', () => {
  const r = RECIPES[0];
  assert.ok(opt.priceOf(r, 130) > opt.priceOf(r, 100));
  assert.ok(opt.priceOf(r, 80) < opt.priceOf(r, 100));
});

test('targets: protein fixed by goal and macros add up to the calorie target', () => {
  for (const goal of Object.keys(GOALS)) {
    const t = opt.targetsFor(goal);
    assert.equal(t.protein, GOALS[goal].p);
    assert.ok(Math.abs(t.protein * 4 + t.carbs * 4 + t.fat * 9 - t.kcal) <= 10);
  }
});

test('repeating the same main ingredient costs exactly 12 points per repeat', () => {
  const { meals } = opt.generatePlan(RECIPES, base, noNoise);
  const distinct = meals.map((m, i) => ({ ...m, tag: 'tag' + i }));
  const oneRepeat = distinct.map((m, i) => (i === 1 ? { ...m, tag: distinct[0].tag } : m));
  const diff = opt.scorePlan(distinct, 'gain', 100) - opt.scorePlan(oneRepeat, 'gain', 100);
  assert.ok(Math.abs(diff - 12) < 1e-9);
});

test('swap keeps the plan within budget, changes the meal and stays in the same slot and diet', () => {
  const params = { budget: 150, diet: 'veg', adj: 100 };
  const { meals } = opt.generatePlan(RECIPES, { ...params, goal: 'gain' }, noNoise);
  for (const slot of SLOTS) {
    const choice = opt.pickSwap(RECIPES, meals, slot, params, noNoise);
    assert.ok(choice, slot);
    const current = meals.find(m => m.slot === slot);
    assert.notEqual(choice.id, current.id);
    assert.equal(choice.slot, slot);
    assert.notEqual(choice.diet, 'nonveg');
    const next = meals.map(m => (m.slot === slot ? choice : m));
    assert.ok(opt.totalsOf(next, 100).cost <= params.budget);
  }
});

test('swap returns null when no alternative exists', () => {
  const params = { budget: 150, diet: 'veg', adj: 100 };
  const { meals } = opt.generatePlan(RECIPES, { ...params, goal: 'gain' }, noNoise);
  assert.equal(opt.pickSwap(meals, meals, 'lunch', params, noNoise), null); // pool contains only the current meals
});

test('swap returns null when every alternative is too expensive', () => {
  const mk = (id, slot, cost) => ({ id, slot, diet: 'vegan', tag: 't' + id, kcal: 500, protein: 20, carbs: 60, fat: 10, ingredients: [{ name: 'x' + id, cost, category: 'c' }] });
  const meals = [mk(1, 'breakfast', 10), mk(2, 'lunch', 10), mk(3, 'snack', 10), mk(4, 'dinner', 10)];
  const catalogue = [...meals, mk(5, 'lunch', 60)]; // only alternative costs far more than the room left
  const params = { budget: 45, diet: 'vegan', adj: 100 };
  assert.equal(opt.pickSwap(catalogue, meals, 'lunch', params, noNoise), null);
  assert.equal(opt.pickSwap(catalogue, meals, 'lunch', { ...params, budget: 100 }, noNoise).id, 5);
});

test('grocery list totals equal the sum of its lines and every ingredient is included', () => {
  const { meals } = opt.generatePlan(RECIPES, base, noNoise);
  const g = opt.groceryList(meals, 100);
  const sum = g.categories.flatMap(c => c.items).reduce((a, i) => a + i.cost, 0);
  assert.equal(g.total, sum);
  const names = new Set(g.categories.flatMap(c => c.items.map(i => i.name)));
  for (const m of meals) for (const i of m.ingredients) assert.ok(names.has(i.name), i.name);
});
