'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { openDb } = require('../src/db');
const { RECIPES } = require('../src/recipes');

const profile = { budget: 120, diet: 'veg', goal: 'gain', adj: 100 };
const picks = { breakfast: 3, lunch: 9, snack: 15, dinner: 21 };

test('seeds all recipes with their ingredients', () => {
  const db = openDb();
  const all = db.getRecipes();
  assert.equal(all.length, RECIPES.length);
  assert.equal(db.getRecipe(1).ingredients.length, RECIPES[0].ingredients.length);
  assert.equal(db.getRecipe(9999), null);
  db.close();
});

test('seeding twice does not duplicate data', () => {
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'pp-')), 'x.db');
  openDb(file).close();
  const db = openDb(file);
  assert.equal(db.getRecipes().length, RECIPES.length);
  assert.equal(db.getRecipe(1).ingredients.length, RECIPES[0].ingredients.length);
  db.close();
});

test('data persists across connections (file database)', () => {
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'pp-')), 'sub', 'x.db');
  const a = openDb(file);
  const id = a.savePlan(profile, picks);
  a.close();
  const b = openDb(file);
  assert.equal(b.loadPlan(id).budget, 120);
  b.close();
});

test('saves and loads a plan with meals in slot order', () => {
  const db = openDb();
  const id = db.savePlan(profile, picks);
  const plan = db.loadPlan(id);
  assert.deepEqual(plan.meals.map(m => m.slot), ['breakfast', 'lunch', 'snack', 'dinner']);
  assert.equal(plan.meals[1].recipe.id, 9);
  assert.equal(db.loadPlan(id + 100), null);
});

test('setMeal updates one slot; deletePlan cascades to its meals', () => {
  const db = openDb();
  const id = db.savePlan(profile, picks);
  assert.equal(db.setMeal(id, 'lunch', 10), true);
  assert.equal(db.loadPlan(id).meals[1].recipe.id, 10);
  assert.equal(db.setMeal(999, 'lunch', 10), false);
  assert.equal(db.deletePlan(id), true);
  assert.equal(db.loadPlan(id), null);
  assert.equal(db.deletePlan(id), false);
});

test('listPlans returns newest first and honours the limit', () => {
  const db = openDb();
  const ids = [1, 2, 3].map(() => db.savePlan(profile, picks));
  const list = db.listPlans(2);
  assert.deepEqual(list.map(p => p.id), [ids[2], ids[1]]);
});

test('database constraints reject bad data even if validation is bypassed', () => {
  const db = openDb();
  assert.throws(() => db.savePlan({ ...profile, budget: 5 }, picks));
  assert.throws(() => db.savePlan({ ...profile, diet: 'keto' }, picks));
  assert.throws(() => db.savePlan(profile, { ...picks, lunch: 9999 })); // unknown recipe (foreign key)
  assert.equal(db.listPlans().length, 0); // failed saves were rolled back
});

test('SQL injection strings are stored as plain data, never executed', () => {
  const db = openDb();
  assert.equal(db.loadPlan("1; DROP TABLE plans;--"), null);
  assert.equal(db.getRecipes().length, RECIPES.length);
});
