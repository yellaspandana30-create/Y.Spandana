'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { RECIPES } = require('../src/recipes');
const { SLOTS, DIETS } = require('../src/config');
const { cheapestCost } = require('../src/optimizer');

test('has at least 50 recipes with unique ids', () => {
  assert.ok(RECIPES.length >= 50);
  assert.equal(new Set(RECIPES.map(r => r.id)).size, RECIPES.length);
});

test('every recipe has valid fields, ingredients and cooking steps', () => {
  for (const r of RECIPES) {
    assert.ok(SLOTS.includes(r.slot), `${r.name}: slot`);
    assert.ok(['vegan', 'veg', 'nonveg'].includes(r.diet), `${r.name}: diet`);
    assert.ok(r.ingredients.length >= 2, `${r.name}: ingredients`);
    assert.ok(r.how.length > 20, `${r.name}: how to cook`);
    for (const i of r.ingredients) assert.ok(i.cost > 0 && i.category, `${r.name}: ${i.name}`);
  }
});

test('calories roughly match macros (4p + 4c + 9f within 8%)', () => {
  for (const r of RECIPES) {
    const calc = r.protein * 4 + r.carbs * 4 + r.fat * 9;
    assert.ok(Math.abs(calc - r.kcal) / r.kcal < 0.08, `${r.name}: listed ${r.kcal}, macros give ${calc}`);
  }
});

test('every slot has at least 3 options for every diet (variety for swaps)', () => {
  for (const diet of DIETS) {
    for (const slot of SLOTS) {
      const n = RECIPES.filter(r => r.slot === slot && (diet === 'nonveg' || (diet === 'veg' ? r.diet !== 'nonveg' : r.diet === 'vegan'))).length;
      assert.ok(n >= 3, `${diet}/${slot} has only ${n}`);
    }
  }
});

test('a default ₹120 budget is feasible for every diet', () => {
  for (const diet of DIETS) assert.ok(cheapestCost(RECIPES, diet, 100) <= 120, diet);
});
