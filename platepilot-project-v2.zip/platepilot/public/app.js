'use strict';

/* PlatePilot front end: a single-page app that talks to the Express/SQLite API.
   No inline scripts or styles anywhere (the server sends a strict Content-Security-Policy). */

const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const LIMITS = { budgetMin: 50, budgetMax: 500, adjMin: 80, adjMax: 130 };
const DIETS = ['veg', 'nonveg', 'vegan'];
const GOALS = ['gain', 'maintain', 'loss'];
const LAST_PLAN_KEY = 'platepilot:lastPlan';
const REQUEST_TIMEOUT_MS = 10000;

let charts = [];
let retryAction = null;
let busy = false;

/* ---------- API client with timeout and friendly network errors ---------- */
class ApiError extends Error {
  constructor(message, status, fields, network = false) {
    super(message);
    this.status = status; this.fields = fields || null; this.network = network;
  }
}

async function api(path, { method = 'GET', body } = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), REQUEST_TIMEOUT_MS);
  let res;
  try {
    res = await fetch('/api' + path, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      signal: ctrl.signal
    });
  } catch (e) {
    throw new ApiError(
      e.name === 'AbortError' ? 'The server took too long to respond.' : 'Cannot reach the PlatePilot server. Check your connection and try again.',
      0, null, true);
  } finally {
    clearTimeout(timer);
  }
  let data = null;
  try { data = await res.json(); } catch (e) { /* non-JSON error page */ }
  if (!res.ok) throw new ApiError((data && data.error) || `Server error (${res.status}).`, res.status, data && data.fields);
  return data;
}

/* ---------- Status, errors, busy state ---------- */
function setStatus(msg, isError = false, canRetry = false) {
  const el = $('status');
  el.textContent = msg;
  el.className = isError ? 'error' : '';
  $('retry').hidden = !(isError && canRetry);
}

function setBusy(on) {
  busy = on;
  $('generate').disabled = on;
  $('generate').textContent = on ? 'Planning…' : 'Generate budget diet plan';
  document.querySelectorAll('.swap').forEach(b => { b.disabled = on; });
}

const FIELDS = ['budget', 'diet', 'goal', 'adj'];
function showFieldErrors(errors = {}) {
  for (const f of FIELDS) {
    const msg = errors[f] || '';
    $(f + 'Err').textContent = msg;
    $(f).setAttribute('aria-invalid', msg ? 'true' : 'false');
  }
  const first = FIELDS.find(f => errors[f]);
  if (first) $(first).focus();
}

/* ---------- Client-side validation (mirrors the server rules, every field) ---------- */
function readProfile() {
  const errors = {};
  const raw = $('budget').value.trim();
  const budget = /^\d{1,6}$/.test(raw) ? Number(raw) : NaN;
  if (!Number.isInteger(budget) || budget < LIMITS.budgetMin || budget > LIMITS.budgetMax) {
    errors.budget = `Enter a whole-number budget between ₹${LIMITS.budgetMin} and ₹${LIMITS.budgetMax}.`;
  }
  const diet = $('diet').value;
  if (!DIETS.includes(diet)) errors.diet = 'Choose a diet from the list.';
  const goal = $('goal').value;
  if (!GOALS.includes(goal)) errors.goal = 'Choose a goal from the list.';
  const adj = Number($('adj').value);
  if (!Number.isInteger(adj) || adj < LIMITS.adjMin || adj > LIMITS.adjMax) {
    errors.adj = `Price adjustment must be between ${LIMITS.adjMin}% and ${LIMITS.adjMax}%.`;
  }
  return { errors, value: { budget, diet, goal, adj } };
}

/* ---------- Actions ---------- */
async function run(action) {
  if (busy) return;
  retryAction = action;
  setBusy(true);
  setStatus('');
  try {
    await action();
  } catch (err) {
    if (err instanceof ApiError) {
      if (err.fields) showFieldErrors(err.fields);
      setStatus(err.message, true, err.network || err.status >= 500);
      if (err.status === 422) $('result').hidden = true;
    } else {
      console.error(err);
      setStatus('Something unexpected went wrong. Please try again.', true, true);
    }
  } finally {
    setBusy(false);
  }
}

async function generate(profile) {
  const plan = await api('/plans', { method: 'POST', body: profile });
  await showPlan(plan);
  refreshHistory();
}

async function swap(planId, slot) {
  const plan = await api(`/plans/${planId}/swap`, { method: 'POST', body: { slot } });
  setStatus(plan.message || '');
  await showPlan(plan);
}

async function openPlan(id) {
  const plan = await api(`/plans/${id}`);
  fillForm(plan.profile);
  await showPlan(plan);
}

function fillForm(p) {
  $('budget').value = p.budget;
  $('diet').value = p.diet;
  $('goal').value = p.goal;
  $('adj').value = p.adj;
  $('adjOut').textContent = p.adj + '%';
}

/* ---------- Rendering ---------- */
async function showPlan(plan) {
  showFieldErrors({});
  try { localStorage.setItem(LAST_PLAN_KEY, String(plan.id)); } catch (e) { /* storage unavailable */ }
  const { totals: tot, targets: T, profile } = plan;

  $('result').hidden = false;
  $('sKcal').textContent = `${tot.kcal} / ${T.kcal}`;
  $('sProt').textContent = `${tot.protein}g / ${T.protein}g`;
  $('meterText').textContent = `₹${tot.cost} of ₹${profile.budget} spent, ₹${plan.remaining} left`;
  $('meterFill').style.width = Math.min(100, tot.cost / profile.budget * 100) + '%';

  $('meals').innerHTML = plan.meals.map(({ slot, recipe: r }) => `
    <article class="meal">
      <div class="meal-head"><h3>${esc(slot)}</h3><span class="badge">₹${r.price}</span></div>
      <h4>${esc(r.name)}</h4>
      <p class="macros">${r.kcal} kcal, ${r.protein}g protein, ${r.carbs}g carbs, ${r.fat}g fat</p>
      <p class="breakdown">${r.ingredients.map(i => `${esc(i.name)} ₹${i.cost}`).join(' + ')} = ₹${r.price}</p>
      <details><summary>How to cook</summary><p>${esc(r.how)}</p></details>
      <button type="button" class="swap" data-slot="${esc(slot)}" data-plan="${plan.id}">Swap ${esc(slot)}</button>
    </article>`).join('');

  drawCharts(tot, T);
  await loadGrocery(plan.id);
}

function drawCharts(tot, T) {
  charts.forEach(c => c.destroy());
  charts = [];
  const plan = { Protein: tot.protein, Carbs: tot.carbs, Fat: tot.fat };
  const target = { Protein: T.protein, Carbs: T.carbs, Fat: T.fat };

  if (typeof Chart === 'undefined') { showChartFallback(plan, target); return; }
  try {
    const make = (id, title, d) => new Chart($(id), {
      type: 'doughnut',
      data: { labels: ['Protein', 'Carbs', 'Fat'], datasets: [{ data: d, backgroundColor: ['#0e6e5c', '#f2b632', '#c2372a'] }] },
      options: { plugins: { title: { display: true, text: title }, legend: { position: 'bottom' } } }
    });
    charts.push(make('planChart', 'Your plan (g)', [plan.Protein, plan.Carbs, plan.Fat]));
    charts.push(make('targetChart', 'Daily target (g)', [target.Protein, target.Carbs, target.Fat]));
    $('charts').hidden = false;
    $('chartFallback').hidden = true;
    $('chartNote').textContent = 'Protein, carbs and fat in grams, compared with your daily targets.';
  } catch (e) {
    console.error(e);
    showChartFallback(plan, target);
  }
}

/* Chart.js comes from a CDN. If it cannot load (offline, blocked), show plain bars instead of nothing. */
function showChartFallback(plan, target) {
  $('charts').hidden = true;
  const box = $('chartFallback');
  box.hidden = false;
  $('chartNote').textContent = 'Charts could not load, so here are simple bars: your plan against your daily targets (in grams).';
  box.innerHTML = Object.keys(plan).map(k => `
    <div class="bar-row">
      <span>${k}</span>
      <div class="bar-track"><div class="bar-fill ${k.toLowerCase()}" data-w="${Math.min(100, Math.round(plan[k] / target[k] * 100))}"></div></div>
      <span>${plan[k]}g / ${target[k]}g</span>
    </div>`).join('');
  box.querySelectorAll('.bar-fill').forEach(el => { el.style.width = el.dataset.w + '%'; });
}

async function loadGrocery(planId) {
  try {
    const g = await api(`/plans/${planId}/grocery`);
    $('groceryTotal').textContent = `Estimated bulk price for 7 days of this plan: ₹${g.total}`;
    $('grocery').innerHTML = g.categories.map(c => `
      <div><h3>${esc(c.category)}</h3><ul>${c.items.map(i => `<li><span>${esc(i.name)}</span><span>₹${i.cost}</span></li>`).join('')}</ul></div>`).join('');
  } catch (err) {
    $('groceryTotal').textContent = 'The grocery list could not be loaded. Press "Try again" or swap a meal to reload it.';
    $('grocery').innerHTML = '';
    retryAction = () => openPlan(planId);
    $('retry').hidden = false;
  }
}

async function refreshHistory() {
  try {
    const { plans } = await api('/plans');
    $('historyPanel').hidden = plans.length === 0;
    $('history').innerHTML = plans.map(p => `
      <li>
        <span><strong>₹${p.budget}</strong> · ${esc(p.diet)} · ${esc(p.goal)} <span class="meta">· ${esc(new Date(p.createdAt).toLocaleString())}</span></span>
        <span>
          <button type="button" data-open="${p.id}">Open</button>
          <button type="button" class="danger" data-delete="${p.id}" aria-label="Delete plan ${p.id}">Delete</button>
        </span>
      </li>`).join('');
  } catch (err) {
    $('historyPanel').hidden = true; // history is a convenience; failing quietly is fine
  }
}

/* ---------- Events ---------- */
$('profile').addEventListener('submit', e => {
  e.preventDefault();
  const { errors, value } = readProfile();
  showFieldErrors(errors);
  if (Object.keys(errors).length) { setStatus('Please fix the highlighted fields.', true); return; }
  run(() => generate(value));
});

$('adj').addEventListener('input', e => { $('adjOut').textContent = e.target.value + '%'; });
$('budget').addEventListener('input', () => { $('budgetErr').textContent = ''; $('budget').setAttribute('aria-invalid', 'false'); });

$('meals').addEventListener('click', e => {
  const btn = e.target.closest('.swap');
  if (btn) run(() => swap(btn.dataset.plan, btn.dataset.slot));
});

$('retry').addEventListener('click', () => { if (retryAction) run(retryAction); });

$('history').addEventListener('click', e => {
  const open = e.target.closest('[data-open]');
  const del = e.target.closest('[data-delete]');
  if (open) run(() => openPlan(open.dataset.open));
  if (del) run(async () => {
    await api(`/plans/${del.dataset.delete}`, { method: 'DELETE' });
    try { if (localStorage.getItem(LAST_PLAN_KEY) === del.dataset.delete) localStorage.removeItem(LAST_PLAN_KEY); } catch (err) { /* ignore */ }
    await refreshHistory();
    setStatus('Plan deleted.');
  });
});

window.addEventListener('offline', () => setStatus('You are offline. Plans can be generated again once you reconnect.', true));
window.addEventListener('online', () => setStatus('Back online.'));

/* ---------- Start-up: restore the last plan from the database ---------- */
(async function init() {
  refreshHistory();
  let id = null;
  try { id = localStorage.getItem(LAST_PLAN_KEY); } catch (e) { /* storage unavailable */ }
  if (!id) return;
  retryAction = () => openPlan(id);
  try {
    await openPlan(id);
  } catch (err) {
    if (err.status === 404) { try { localStorage.removeItem(LAST_PLAN_KEY); } catch (e) { /* ignore */ } }
    else if (err.network) setStatus(err.message, true, true);
  }
})();
