'use strict';
const path = require('node:path');
const express = require('express');
const { createController } = require('./controllers');

/* In-memory fixed-window rate limiter (per IP). Enough to blunt abuse of the plan generator. */
function rateLimit({ windowMs = 60_000, max = 120 } = {}) {
  const hits = new Map();
  setInterval(() => hits.clear(), windowMs).unref();
  return (req, res, next) => {
    const n = (hits.get(req.ip) || 0) + 1;
    hits.set(req.ip, n);
    if (n > max) return res.status(429).json({ error: 'Too many requests. Please wait a minute and try again.' });
    next();
  };
}

function securityHeaders(req, res, next) {
  res.set({
    'Content-Security-Policy': [
      "default-src 'self'",
      "script-src 'self' https://cdn.jsdelivr.net",
      "style-src 'self' https://fonts.googleapis.com",
      "font-src https://fonts.gstatic.com",
      "img-src 'self' data:",
      "connect-src 'self'",
      "object-src 'none'",
      "base-uri 'self'",
      "frame-ancestors 'none'"
    ].join('; '),
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer'
  });
  next();
}

function createApp(db, options = {}) {
  const c = createController(db, options);
  const app = express();
  app.disable('x-powered-by');
  app.use(securityHeaders);
  app.use('/api', rateLimit(options.rateLimit));
  app.use(express.json({ limit: '10kb' }));

  const send = (res, out) => res.status(out.status).json(out.body);

  app.get('/api/health',            (req, res) => send(res, c.health()));
  app.get('/api/recipes',           (req, res) => send(res, c.listRecipes(req.query)));
  app.get('/api/plans',             (req, res) => send(res, c.listPlans()));
  app.post('/api/plans',            (req, res) => send(res, c.createPlan(req.body)));
  app.get('/api/plans/:id',         (req, res) => send(res, c.getPlan(req.params.id)));
  app.post('/api/plans/:id/swap',   (req, res) => send(res, c.swapMeal(req.params.id, req.body)));
  app.get('/api/plans/:id/grocery', (req, res) => send(res, c.getGrocery(req.params.id)));
  app.delete('/api/plans/:id',      (req, res) => send(res, c.deletePlan(req.params.id)));

  app.use('/api', (req, res) => res.status(404).json({ error: 'Unknown API route.' }));
  app.use(express.static(path.join(__dirname, '..', 'public')));

  // Malformed JSON and any unexpected error end up here; never leak stack traces to the client.
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Request body is not valid JSON.' });
    if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Request body is too large.' });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong on the server.' });
  });
  return app;
}

module.exports = { createApp };
