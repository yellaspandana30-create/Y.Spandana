'use strict';
const { SLOTS, DIETS, GOALS, LIMITS } = require('./config');

const isPlainObject = v => v !== null && typeof v === 'object' && !Array.isArray(v);
const isInt = v => typeof v === 'number' && Number.isInteger(v);

/* Accepts numbers or numeric strings ("120"), rejects everything else (NaN, "", "1e3abc", objects). */
function toInt(v) {
  if (isInt(v)) return v;
  if (typeof v === 'string' && /^\s*\d{1,6}\s*$/.test(v)) return Number(v.trim());
  return null;
}

/* Validates the student profile. Returns { ok, value, errors } where errors is keyed by field name,
   so the UI can show the message next to the right input. */
function validateProfile(body) {
  const errors = {};
  if (!isPlainObject(body)) return { ok: false, errors: { body: 'Request body must be a JSON object.' } };

  const budget = toInt(body.budget);
  if (budget === null || budget < LIMITS.budgetMin || budget > LIMITS.budgetMax) {
    errors.budget = `Budget must be a whole number between ₹${LIMITS.budgetMin} and ₹${LIMITS.budgetMax}.`;
  }
  if (typeof body.diet !== 'string' || !DIETS.includes(body.diet)) {
    errors.diet = `Diet must be one of: ${DIETS.join(', ')}.`;
  }
  if (typeof body.goal !== 'string' || !Object.prototype.hasOwnProperty.call(GOALS, body.goal)) {
    errors.goal = `Goal must be one of: ${Object.keys(GOALS).join(', ')}.`;
  }
  const adj = body.adj === undefined ? 100 : toInt(body.adj);
  if (adj === null || adj < LIMITS.adjMin || adj > LIMITS.adjMax) {
    errors.adj = `Local price adjustment must be between ${LIMITS.adjMin}% and ${LIMITS.adjMax}%.`;
  }
  if (Object.keys(errors).length) return { ok: false, errors };
  return { ok: true, value: { budget, diet: body.diet, goal: body.goal, adj }, errors };
}

function validateSlot(body) {
  if (!isPlainObject(body) || typeof body.slot !== 'string' || !SLOTS.includes(body.slot)) {
    return { ok: false, errors: { slot: `Slot must be one of: ${SLOTS.join(', ')}.` } };
  }
  return { ok: true, value: body.slot, errors: {} };
}

function validateId(raw) {
  const id = toInt(raw);
  if (id === null || id < 1) return { ok: false, errors: { id: 'Id must be a positive whole number.' } };
  return { ok: true, value: id, errors: {} };
}

function validateRecipeFilter(query) {
  const errors = {};
  const q = isPlainObject(query) ? query : {};
  if (q.diet !== undefined && !DIETS.includes(q.diet)) errors.diet = `Diet must be one of: ${DIETS.join(', ')}.`;
  if (q.slot !== undefined && !SLOTS.includes(q.slot)) errors.slot = `Slot must be one of: ${SLOTS.join(', ')}.`;
  if (Object.keys(errors).length) return { ok: false, errors };
  return { ok: true, value: { diet: q.diet, slot: q.slot }, errors };
}

module.exports = { validateProfile, validateSlot, validateId, validateRecipeFilter };
