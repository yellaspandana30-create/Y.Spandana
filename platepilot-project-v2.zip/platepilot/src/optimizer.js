'use strict';
const { SLOTS, GOALS } = require('./config');

/* Pure functions only: no database, no HTTP. This keeps the maths easy to unit test. */

const priceOfIngredient = (ing, adj) => Math.round(ing.cost * adj / 100);
const priceOf = (recipe, adj) => recipe.ingredients.reduce((sum, i) => sum + priceOfIngredient(i, adj), 0);

function isAllowed(recipe, diet) {
  if (diet === 'nonveg') return true;
  if (diet === 'veg') return recipe.diet !== 'nonveg';
  return recipe.diet === 'vegan';
}

const poolFor = (recipes, slot, diet) => recipes.filter(r => r.slot === slot && isAllowed(r, diet));

function totalsOf(meals, adj) {
  return meals.reduce((t, r) => ({
    kcal: t.kcal + r.kcal, protein: t.protein + r.protein,
    carbs: t.carbs + r.carbs, fat: t.fat + r.fat, cost: t.cost + priceOf(r, adj)
  }), { kcal: 0, protein: 0, carbs: 0, fat: 0, cost: 0 });
}

/* Daily targets. Fat is 25% of calories, protein is fixed by goal, carbs fill the remainder. */
function targetsFor(goal) {
  const T = GOALS[goal];
  const fat = Math.round(T.k * 0.25 / 9);
  const carbs = Math.round((T.k - T.p * 4 - fat * 9) / 4);
  return { kcal: T.k, protein: T.p, carbs, fat };
}

/* Score for a candidate day: closeness to protein and calorie targets, minus a penalty for
   repeating the same main ingredient. `noise` is a small random jitter (0 in tests). */
function scorePlan(meals, goal, adj, noise = 0) {
  const T = GOALS[goal];
  const tot = totalsOf(meals, adj);
  const repeats = meals.length - new Set(meals.map(r => r.tag)).size;
  return Math.min(tot.protein / T.p, 1.1) * 50
       + (1 - Math.min(1, Math.abs(tot.kcal - T.k) / T.k)) * 40
       - repeats * 12
       + noise;
}

function cheapestCost(recipes, diet, adj) {
  return SLOTS.reduce((sum, slot) => {
    const pool = poolFor(recipes, slot, diet);
    return sum + (pool.length ? Math.min(...pool.map(r => priceOf(r, adj))) : Infinity);
  }, 0);
}

/* Multiple-choice knapsack: exactly one meal per slot, total cost <= budget, maximise score.
   Searched exhaustively with budget pruning, so the answer is exact (not greedy).
   Returns { meals: [recipe x4 in SLOTS order] } or { error, cheapest }. */
function generatePlan(recipes, { budget, diet, goal, adj }, rng = Math.random) {
  const pools = SLOTS.map(slot => poolFor(recipes, slot, diet));
  if (pools.some(p => p.length === 0)) {
    return { error: 'No recipes are available for this diet.', cheapest: null };
  }
  const cheapest = cheapestCost(recipes, diet, adj);
  if (cheapest > budget) {
    return { error: `₹${budget} is too low for four meals. The cheapest plan for this diet costs ₹${cheapest}.`, cheapest };
  }
  // cheapest remaining cost from slot i onwards, used to prune branches that can never fit
  const minFrom = new Array(SLOTS.length + 1).fill(0);
  for (let i = SLOTS.length - 1; i >= 0; i--) {
    minFrom[i] = minFrom[i + 1] + Math.min(...pools[i].map(r => priceOf(r, adj)));
  }
  let best = null;
  (function walk(i, pick, cost) {
    if (cost + minFrom[i] > budget) return;
    if (i === SLOTS.length) {
      const sc = scorePlan(pick, goal, adj, rng() * 4);
      if (!best || sc > best.score) best = { score: sc, meals: [...pick] };
      return;
    }
    for (const r of pools[i]) {
      pick.push(r);
      walk(i + 1, pick, cost + priceOf(r, adj));
      pick.pop();
    }
  })(0, [], 0);
  return { meals: best.meals };
}

/* Replace one meal with a similar one (calories, protein, price) that still fits the budget. */
function pickSwap(recipes, currentMeals, slot, { budget, diet, adj }, rng = Math.random) {
  const current = currentMeals.find(m => m.slot === slot);
  const others = currentMeals.filter(m => m.slot !== slot).reduce((a, m) => a + priceOf(m, adj), 0);
  const room = budget - others;
  const options = poolFor(recipes, slot, diet)
    .filter(r => r.id !== current.id && priceOf(r, adj) <= room)
    .map(r => ({
      r,
      d: Math.abs(r.kcal - current.kcal) / current.kcal
       + Math.abs(r.protein - current.protein) / Math.max(current.protein, 1)
       + Math.abs(priceOf(r, adj) - priceOf(current, adj)) / budget
    }))
    .sort((a, b) => a.d - b.d || a.r.id - b.r.id);
  if (!options.length) return null;
  return options[Math.floor(rng() * Math.min(2, options.length))].r;
}

/* Weekly grocery list: 7 days of the plan at a ~10% bulk discount, grouped by category. */
function groceryList(meals, adj) {
  const items = new Map();
  for (const r of meals) {
    for (const i of r.ingredients) {
      const o = items.get(i.name) || { name: i.name, category: i.category, cost: 0 };
      o.cost += priceOfIngredient(i, adj) * 7 * 0.9;
      items.set(i.name, o);
    }
  }
  const groups = {};
  let total = 0;
  for (const o of items.values()) {
    const cost = Math.round(o.cost);
    total += cost;
    (groups[o.category] = groups[o.category] || []).push({ name: o.name, cost });
  }
  const categories = Object.keys(groups).sort().map(category => ({
    category, items: groups[category].sort((a, b) => a.name.localeCompare(b.name))
  }));
  return { total, categories };
}

module.exports = { priceOf, isAllowed, poolFor, totalsOf, targetsFor, scorePlan, cheapestCost, generatePlan, pickSwap, groceryList };
