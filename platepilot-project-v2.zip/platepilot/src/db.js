'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { RECIPES } = require('./recipes');
const { SLOTS } = require('./config');

const SCHEMA = `
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS recipes (
    id      INTEGER PRIMARY KEY,
    name    TEXT NOT NULL,
    slot    TEXT NOT NULL CHECK (slot IN ('breakfast','lunch','snack','dinner')),
    diet    TEXT NOT NULL CHECK (diet IN ('vegan','veg','nonveg')),
    tag     TEXT NOT NULL,
    kcal    INTEGER NOT NULL CHECK (kcal > 0),
    protein INTEGER NOT NULL CHECK (protein >= 0),
    carbs   INTEGER NOT NULL CHECK (carbs >= 0),
    fat     INTEGER NOT NULL CHECK (fat >= 0),
    how     TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS ingredients (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    recipe_id INTEGER NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
    name      TEXT NOT NULL,
    cost      INTEGER NOT NULL CHECK (cost >= 0),
    category  TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS plans (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    budget     INTEGER NOT NULL CHECK (budget BETWEEN 50 AND 500),
    diet       TEXT NOT NULL CHECK (diet IN ('vegan','veg','nonveg')),
    goal       TEXT NOT NULL CHECK (goal IN ('loss','maintain','gain')),
    adj        INTEGER NOT NULL CHECK (adj BETWEEN 80 AND 130)
  );
  CREATE TABLE IF NOT EXISTS plan_meals (
    plan_id   INTEGER NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
    slot      TEXT NOT NULL CHECK (slot IN ('breakfast','lunch','snack','dinner')),
    recipe_id INTEGER NOT NULL REFERENCES recipes(id),
    PRIMARY KEY (plan_id, slot)
  );
  CREATE INDEX IF NOT EXISTS idx_ingredients_recipe ON ingredients(recipe_id);
`;

/* All SQL lives here. Every statement is parameterised (no string concatenation of user input). */
function openDb(file = ':memory:') {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec(SCHEMA);

  const tx = fn => {
    db.exec('BEGIN');
    try { const out = fn(); db.exec('COMMIT'); return out; }
    catch (e) { db.exec('ROLLBACK'); throw e; }
  };

  function seed() {
    const { n } = db.prepare('SELECT COUNT(*) AS n FROM recipes').get();
    if (n === RECIPES.length) return;
    const insR = db.prepare('INSERT OR REPLACE INTO recipes (id,name,slot,diet,tag,kcal,protein,carbs,fat,how) VALUES (?,?,?,?,?,?,?,?,?,?)');
    const delI = db.prepare('DELETE FROM ingredients WHERE recipe_id = ?');
    const insI = db.prepare('INSERT INTO ingredients (recipe_id,name,cost,category) VALUES (?,?,?,?)');
    tx(() => {
      for (const r of RECIPES) {
        insR.run(r.id, r.name, r.slot, r.diet, r.tag, r.kcal, r.protein, r.carbs, r.fat, r.how);
        delI.run(r.id);
        for (const i of r.ingredients) insI.run(r.id, i.name, i.cost, i.category);
      }
    });
  }
  seed();

  const withIngredients = rows => {
    const ing = db.prepare('SELECT name, cost, category FROM ingredients WHERE recipe_id = ? ORDER BY id');
    return rows.map(r => ({ ...r, ingredients: ing.all(r.id) }));
  };

  const getRecipes = () => withIngredients(db.prepare('SELECT * FROM recipes ORDER BY id').all());
  const getRecipe = id => withIngredients(db.prepare('SELECT * FROM recipes WHERE id = ?').all(id))[0] || null;

  function loadPlan(id) {
    const plan = db.prepare('SELECT id, created_at AS createdAt, budget, diet, goal, adj FROM plans WHERE id = ?').get(id);
    if (!plan) return null;
    const rows = db.prepare('SELECT slot, recipe_id FROM plan_meals WHERE plan_id = ?').all(id);
    const meals = SLOTS.map(slot => {
      const row = rows.find(r => r.slot === slot);
      return row ? { slot, recipe: getRecipe(row.recipe_id) } : null;
    }).filter(Boolean);
    return { ...plan, meals };
  }

  function savePlan(profile, recipesBySlot) {
    return tx(() => {
      const res = db.prepare('INSERT INTO plans (budget, diet, goal, adj) VALUES (?,?,?,?)')
        .run(profile.budget, profile.diet, profile.goal, profile.adj);
      const id = Number(res.lastInsertRowid);
      const ins = db.prepare('INSERT INTO plan_meals (plan_id, slot, recipe_id) VALUES (?,?,?)');
      for (const slot of SLOTS) ins.run(id, slot, recipesBySlot[slot]);
      return id;
    });
  }

  const setMeal = (planId, slot, recipeId) =>
    db.prepare('UPDATE plan_meals SET recipe_id = ? WHERE plan_id = ? AND slot = ?').run(recipeId, planId, slot).changes > 0;

  const listPlans = (limit = 10) =>
    db.prepare('SELECT id, created_at AS createdAt, budget, diet, goal, adj FROM plans ORDER BY id DESC LIMIT ?').all(limit);

  const deletePlan = id => db.prepare('DELETE FROM plans WHERE id = ?').run(id).changes > 0;

  return { getRecipes, getRecipe, loadPlan, savePlan, setMeal, listPlans, deletePlan, close: () => db.close() };
}

module.exports = { openDb };
