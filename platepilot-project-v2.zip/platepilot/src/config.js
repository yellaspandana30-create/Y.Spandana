'use strict';

const SLOTS = ['breakfast', 'lunch', 'snack', 'dinner'];
const DIETS = ['veg', 'nonveg', 'vegan'];
const GOALS = {
  loss:     { k: 1700, p: 80 },
  maintain: { k: 2000, p: 65 },
  gain:     { k: 2300, p: 95 }
};
const LIMITS = { budgetMin: 50, budgetMax: 500, adjMin: 80, adjMax: 130 };

module.exports = { SLOTS, DIETS, GOALS, LIMITS };
