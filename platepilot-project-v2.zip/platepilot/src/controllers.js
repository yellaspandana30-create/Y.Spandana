'use strict';
const { SLOTS } = require('./config');
const opt = require('./optimizer');
const v = require('./validate');

/* Framework-free request handlers: each returns { status, body }.
   Express (src/app.js) only maps HTTP onto these, so the logic is testable without a server. */
const ok = (body, status = 200) => ({ status, body });
const fail = (status, error, fields) => ({ status, body: { error, ...(fields ? { fields } : {}) } });

function createController(db, { rng = Math.random } = {}) {
  /* Turn a stored plan into the JSON the UI needs: prices, totals and targets are computed here. */
  function present(plan) {
    const meals = plan.meals.map(m => ({
      slot: m.slot,
      recipe: {
        id: m.recipe.id, name: m.recipe.name, diet: m.recipe.diet, tag: m.recipe.tag,
        kcal: m.recipe.kcal, protein: m.recipe.protein, carbs: m.recipe.carbs, fat: m.recipe.fat,
        how: m.recipe.how, price: opt.priceOf(m.recipe, plan.adj),
        ingredients: m.recipe.ingredients.map(i => ({ name: i.name, cost: opt.priceOf({ ingredients: [i] }, plan.adj), category: i.category }))
      }
    }));
    const recipes = plan.meals.map(m => m.recipe);
    const totals = opt.totalsOf(recipes, plan.adj);
    return {
      id: plan.id, createdAt: plan.createdAt,
      profile: { budget: plan.budget, diet: plan.diet, goal: plan.goal, adj: plan.adj },
      meals, totals, targets: opt.targetsFor(plan.goal), remaining: plan.budget - totals.cost
    };
  }


  return {
    health() {
      return ok({ status: 'ok', recipes: db.getRecipes().length });
    },

    listRecipes(query) {
      const f = v.validateRecipeFilter(query);
      if (!f.ok) return fail(400, 'Invalid filter.', f.errors);
      let list = db.getRecipes();
      if (f.value.slot) list = list.filter(r => r.slot === f.value.slot);
      if (f.value.diet) list = list.filter(r => opt.isAllowed(r, f.value.diet));
      return ok({ count: list.length, recipes: list });
    },

    createPlan(body) {
      const p = v.validateProfile(body);
      if (!p.ok) return fail(400, 'Please fix the highlighted fields.', p.errors);
      const result = opt.generatePlan(db.getRecipes(), p.value, rng);
      if (result.error) return fail(422, result.error, result.cheapest ? { budget: result.error } : undefined);
      const bySlot = {};
      result.meals.forEach(r => { bySlot[r.slot] = r.id; });
      return ok(present(db.loadPlan(db.savePlan(p.value, bySlot))), 201);
    },

    getPlan(rawId) {
      const id = v.validateId(rawId);
      if (!id.ok) return fail(400, 'Invalid plan id.', id.errors);
      const plan = db.loadPlan(id.value);
      return plan ? ok(present(plan)) : fail(404, 'Plan not found.');
    },

    listPlans() {
      return ok({ plans: db.listPlans(10) });
    },

    swapMeal(rawId, body) {
      const id = v.validateId(rawId);
      if (!id.ok) return fail(400, 'Invalid plan id.', id.errors);
      const slot = v.validateSlot(body);
      if (!slot.ok) return fail(400, 'Invalid slot.', slot.errors);
      const plan = db.loadPlan(id.value);
      if (!plan) return fail(404, 'Plan not found.');
      const current = plan.meals.map(m => ({ ...m.recipe }));
      const choice = opt.pickSwap(db.getRecipes(), current, slot.value, plan, rng);
      if (!choice) return fail(409, `No other ${slot.value} option fits your budget and diet.`);
      db.setMeal(plan.id, slot.value, choice.id);
      const out = present(db.loadPlan(plan.id));
      out.message = `Swapped ${slot.value} to ${choice.name}.`;
      return ok(out);
    },

    getGrocery(rawId) {
      const id = v.validateId(rawId);
      if (!id.ok) return fail(400, 'Invalid plan id.', id.errors);
      const plan = db.loadPlan(id.value);
      if (!plan) return fail(404, 'Plan not found.');
      return ok(opt.groceryList(plan.meals.map(m => m.recipe), plan.adj));
    },

    deletePlan(rawId) {
      const id = v.validateId(rawId);
      if (!id.ok) return fail(400, 'Invalid plan id.', id.errors);
      return db.deletePlan(id.value) ? ok({ deleted: id.value }) : fail(404, 'Plan not found.');
    }
  };
}

module.exports = { createController, SLOTS };
