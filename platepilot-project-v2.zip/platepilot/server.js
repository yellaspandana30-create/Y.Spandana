'use strict';
const path = require('node:path');
const { openDb } = require('./src/db');
const { createApp } = require('./src/app');

const PORT = Number(process.env.PORT) || 3000;
const DB_FILE = process.env.PLATEPILOT_DB || path.join(__dirname, 'data', 'platepilot.db');

const db = openDb(DB_FILE);
const server = createApp(db).listen(PORT, () => {
  console.log(`PlatePilot running at http://localhost:${PORT}  (database: ${DB_FILE})`);
});

function shutdown() { server.close(() => { db.close(); process.exit(0); }); }
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
