# PlatePilot: Budget Diet Planner for Students

Balanced daily meals for the money a student actually has. Enter a daily budget, diet and goal, and PlatePilot
finds the best four-meal day (breakfast, lunch, snack, dinner) that fits the budget, shows the cost of every
ingredient, draws a macro chart, and builds a weekly grocery list.

## Run it

Requires **Node.js 22.5 or newer** (SQLite is built in, so there is nothing to compile).

```bash
npm install
npm start          # http://localhost:3000
npm test           # 52 automated tests
```

Optional: `PORT=8080` and `PLATEPILOT_DB=/path/to/file.db` environment variables.

## Architecture (3-tier)

```
Browser (public/)            Express API (src/app.js)          SQLite (src/db.js)
HTML + CSS + vanilla JS  -->  routes, JSON, security headers --> recipes, ingredients,
validation, rendering,        controllers.js (logic)             plans, plan_meals
Chart.js, error handling      validate.js, optimizer.js          (data/platepilot.db)
```

| Layer | Files | Responsibility |
|---|---|---|
| Presentation | `public/index.html`, `style.css`, `app.js` | Form, JS validation, meal cards, charts, grocery list, history, error and offline handling |
| Application | `src/app.js`, `src/controllers.js`, `src/validate.js`, `src/optimizer.js` | HTTP routing, server-side validation, budget optimiser, swap logic, grocery maths |
| Data | `src/db.js`, `src/recipes.js` | SQLite schema with constraints, seeding 50 recipes, parameterised queries |

Controllers are plain functions (`input -> {status, body}`), so all logic is tested without a web server.

## Requirements covered

| Requirement | Where |
|---|---|
| Student budget and macro profiler | Form in `public/index.html`; targets in `optimizer.targetsFor` |
| Budget diet plan generator (exact optimisation) | `optimizer.generatePlan`: multiple-choice knapsack, exhaustive search with budget pruning |
| Meal cards with ingredient cost breakdown | `public/app.js` `showPlan` |
| Swap a meal within budget | `POST /api/plans/:id/swap`, `optimizer.pickSwap` |
| Macro balance visualiser | Chart.js doughnuts with a plain-bar fallback if the CDN is unreachable |
| Weekly grocery list | `GET /api/plans/:id/grocery`, `optimizer.groceryList` |
| Local price adjustment | `adj` slider (80% to 130%) applied to every ingredient price |
| 50 recipes, 3 diets | `src/recipes.js`, checked by `test/recipes.test.js` |
| Node.js/Express backend + SQLite | `server.js`, `src/app.js`, `src/db.js` |
| Plans persist | SQLite `plans` + `plan_meals`; last plan restored on reload; recent-plans list |

## REST API

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Status and recipe count |
| GET | `/api/recipes?diet=&slot=` | Browse recipes |
| POST | `/api/plans` | Create a plan from `{budget, diet, goal, adj}` (201, 400 invalid, 422 budget too low) |
| GET | `/api/plans` | Ten most recent plans |
| GET | `/api/plans/:id` | One plan with meals, totals, targets |
| POST | `/api/plans/:id/swap` | Swap `{slot}` (409 if nothing fits) |
| GET | `/api/plans/:id/grocery` | Weekly grocery list |
| DELETE | `/api/plans/:id` | Delete a plan |

## Security and reliability

- **Validation on both sides.** The browser checks every field in JS (not just HTML attributes); the server
  re-validates every field and every id (`src/validate.js`), returning per-field messages. SQLite `CHECK`
  constraints are a third safety net.
- **No SQL injection.** Every query is parameterised; ids are validated as integers first.
- **No XSS.** All API text is escaped before it reaches the DOM; a strict Content-Security-Policy forbids
  inline scripts and styles.
- Security headers (`nosniff`, frame denial, no referrer), `x-powered-by` removed, 10 kB JSON body limit,
  per-IP rate limiting, and no stack traces in error responses.
- **Network failures.** Requests time out after 10 s; offline, dropped and failed requests show a clear message
  with a "Try again" button. If Chart.js cannot load, simple bars replace the charts.
- Authentication is not part of the brief (single-user planner); there are no secrets in the code.

## Tests

`npm test` runs 52 tests with Node's built-in runner:

- `recipes.test.js`: data integrity (50 unique recipes, calories match macros, every diet is feasible)
- `optimizer.test.js`: budget never exceeded, diet rules, **optimality against brute force**, swaps, grocery maths
- `validate.test.js`: bad numbers, prototype keys, injection strings, extra fields
- `db.test.js`: seeding, persistence across connections, constraints, cascade delete
- `controllers.test.js`: every endpoint's success, 400, 404, 409 and 422 paths
- `http.test.js`: end-to-end through real HTTP, security headers, rate limiting, bad JSON
