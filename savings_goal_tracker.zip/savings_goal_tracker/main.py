#!/usr/bin/env python3
"""
Savings Goal Tracker — Interactive Terminal Application
GreenFuture Hack | Project #13
"""

import sys
import subprocess
from typing import List, Dict, Any

from src.models import VALID_CATEGORIES, VALID_PRIORITIES
from src.validators import (
    ValidationError,
    prompt_text,
    prompt_amount,
    prompt_date,
    prompt_choice,
)
from src.engine import SavingsTrackerEngine
from src.analytics import AnalyticsEngine
from src.exporter import ReportExporterAndImporter

# ANSI Color Palette
RESET = "\033[0m"
BOLD = "\033[1m"
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
DIM = "\033[2m"


def clear_divider() -> None:
    print(f"{DIM}" + "─" * 92 + f"{RESET}")


def print_banner() -> None:
    print(f"\n{CYAN}{BOLD}╔══════════════════════════════════════════════════════════════════════════════════════════╗")
    print("║                     SAVINGS GOAL TRACKER  |  GREENFUTURE HACK #13                        ║")
    print("║            Personal Finance & Target Management Utility (CLI + Streamlit GUI)            ║")
    print(f"╚══════════════════════════════════════════════════════════════════════════════════════════╝{RESET}")


def status_badge(status: str) -> str:
    colors = {
        "Completed": GREEN,
        "On Track": CYAN,
        "Behind Schedule": YELLOW,
        "At Risk": YELLOW,
        "Overdue": RED,
    }
    c = colors.get(status, RESET)
    return f"{c}{status:<15}{RESET}"


def render_paginated_goals_table(records: List[Dict[str, Any]], page_size: int = 10) -> None:
    """Render fixed-width ASCII/Unicode table with pagination breaks for large datasets."""
    if not records:
        print(f"  {YELLOW}No matching savings goal records found.{RESET}")
        return

    total = len(records)
    total_pages = (total + page_size - 1) // page_size
    page = 1

    while True:
        start = (page - 1) * page_size
        end = min(start + page_size, total)
        chunk = records[start:end]

        print(f"\n{BOLD}  Showing records {start + 1}–{end} of {total} (Page {page}/{total_pages}){RESET}")
        header = (
            f"  {'ID':<9} | {'Title':<24} | {'Category':<18} | {'Saved / Target':<23} | "
            f"{'Prog%':>6} | {'Deadline':<10} | {'Status':<15}"
        )
        print(f"{BOLD}{header}{RESET}")
        print("  " + "-" * 118)

        for g in chunk:
            title_short = (g["title"][:21] + "...") if len(g["title"]) > 24 else g["title"]
            cat_short = (g["category"][:15] + "...") if len(g["category"]) > 18 else g["category"]
            money_col = f"${g['current_amount']:,.0f} / ${g['target_amount']:,.0f}"
            print(
                f"  {g['goal_id']:<9} | {title_short:<24} | {cat_short:<18} | {money_col:<23} | "
                f"{g['progress_pct']:>5.1f}% | {g['deadline']:<10} | {status_badge(g['status'])}"
            )

        if total_pages <= 1:
            break

        nav = input(f"\n  {DIM}[N]ext page | [P]revious page | [Q]uit table view: {RESET}").strip().lower()
        if nav == "n" and page < total_pages:
            page += 1
        elif nav == "p" and page > 1:
            page -= 1
        elif nav == "q" or nav == "":
            break
        else:
            print(f"  {YELLOW}Boundary reached or invalid navigation key.{RESET}")


def handle_create_goal(engine: SavingsTrackerEngine) -> None:
    print(f"\n{CYAN}{BOLD}[1] Create New Savings Goal{RESET}")
    clear_divider()
    title = prompt_text("Goal Title", min_len=2, max_len=80)
    category = prompt_choice("Select Category", VALID_CATEGORIES, default="Emergency Fund")
    target = prompt_amount("Target Amount ($)", min_val=1.00)
    initial = prompt_amount("Initial Deposit ($)", min_val=0.0, allow_zero=True, default=0.0)
    deadline = prompt_date("Target Deadline", must_be_future=False)
    priority = prompt_choice("Select Priority", VALID_PRIORITIES, default="Medium")
    notes = prompt_text("Optional Notes", max_len=200, allow_empty=True, default="")

    try:
        goal, warnings = engine.add_goal(
            title=title,
            category=category,
            target_amount=target,
            deadline=deadline,
            initial_amount=initial,
            priority=priority,
            notes=notes,
        )
        print(f"\n  {GREEN}{BOLD}✔ Goal '{goal.title}' ({goal.goal_id}) saved successfully!{RESET}")
        for w in warnings:
            print(f"  {YELLOW}⚠ {w}{RESET}")
    except ValidationError as err:
        print(f"  {RED}[Error] {err}{RESET}")


def handle_record_deposit(engine: SavingsTrackerEngine) -> None:
    print(f"\n{CYAN}{BOLD}[2] Record Savings Deposit{RESET}")
    clear_divider()
    goals = engine.get_all_enriched_goals()
    if not goals:
        print(f"  {YELLOW}No goals exist yet. Create a goal first.{RESET}")
        return

    render_paginated_goals_table(goals, page_size=15)
    gid = prompt_text("Enter Target Goal ID (e.g., GOAL-101)", min_len=2, max_len=20).upper()
    goal = engine.get_goal_by_id(gid)
    if not goal:
        print(f"  {RED}[Error] Goal ID '{gid}' not found.{RESET}")
        return

    metrics = engine.compute_goal_metrics(goal)
    print(f"  Selected: {BOLD}{goal.title}{RESET} | Current: ${goal.current_amount:,.2f} / ${goal.target_amount:,.2f} (Remaining: ${metrics['remaining_amount']:,.2f})")
    amount = prompt_amount("Deposit Amount ($)", min_val=0.01)
    tx_date = prompt_date("Deposit Date", default=None)
    note = prompt_text("Deposit Note", max_len=150, allow_empty=True, default="Regular savings contribution")

    try:
        tx, updated_goal, warnings = engine.record_deposit(
            goal_id=gid,
            amount=amount,
            transaction_date=tx_date,
            note=note,
            source="Terminal CLI",
        )
        new_metrics = engine.compute_goal_metrics(updated_goal)
        print(f"\n  {GREEN}{BOLD}✔ Deposit {tx.transaction_id} (${tx.amount:,.2f}) recorded!{RESET}")
        print(f"  Updated Progress: ${updated_goal.current_amount:,.2f} / ${updated_goal.target_amount:,.2f} ({new_metrics['progress_pct']:.1f}% - {new_metrics['status']})")
        for w in warnings:
            print(f"  {YELLOW}⚠ {w}{RESET}")
    except ValidationError as err:
        print(f"  {RED}[Error] {err}{RESET}")


def handle_search_and_filter(engine: SavingsTrackerEngine) -> None:
    print(f"\n{CYAN}{BOLD}[4] Search & Filter Savings Goals{RESET}")
    clear_divider()
    keyword = prompt_text("Keyword (title/ID/notes, leave blank for all)", allow_empty=True, default="")
    cat_options = ["All"] + VALID_CATEGORIES
    category = prompt_choice("Filter by Category", cat_options, default="All")
    status_options = ["All", "On Track", "Behind Schedule", "At Risk", "Overdue", "Completed"]
    status = prompt_choice("Filter by Status", status_options, default="All")

    results = engine.search_goals(keyword=keyword, category=category, status=status)
    render_paginated_goals_table(results, page_size=10)


def handle_goal_details_and_edit(engine: SavingsTrackerEngine) -> None:
    print(f"\n{CYAN}{BOLD}[5] Inspect Goal Details / Update / Delete{RESET}")
    clear_divider()
    gid = prompt_text("Enter Goal ID (e.g., GOAL-101)", min_len=2, max_len=20).upper()
    goal = engine.get_goal_by_id(gid)
    if not goal:
        print(f"  {RED}[Error] Goal '{gid}' not found.{RESET}")
        return

    m = engine.compute_goal_metrics(goal)
    print(f"\n  {BOLD}{m['goal_id']} — {m['title']}{RESET}")
    print(f"  Category        : {m['category']} | Priority: {m['priority']}")
    print(f"  Target Amount   : ${m['target_amount']:,.2f}")
    print(f"  Current Saved   : ${m['current_amount']:,.2f} ({m['progress_pct']:.2f}%)")
    print(f"  Remaining       : ${m['remaining_amount']:,.2f}")
    print(f"  Deadline        : {m['deadline']} ({m['days_remaining']} days remaining)")
    print(f"  Required Pace   : ${m['required_daily']:,.2f}/day | ${m['required_monthly']:,.2f}/month")
    print(f"  Status          : {status_badge(m['status'])}")
    print(f"  Notes           : {m['notes'] or 'None'}")

    txs = engine.get_goal_transactions(gid)
    print(f"\n  Recent Deposits ({len(txs)} total):")
    for t in txs[:8]:
        print(f"    • {t.transaction_date} | {t.transaction_id} | ${t.amount:,.2f} | {t.note}")

    action = input(f"\n  Action: [U]pdate target/deadline | [D]elete goal | [Enter] to return: ").strip().lower()
    if action == "u":
        new_target = prompt_amount("New Target Amount ($)", min_val=1.00, default=goal.target_amount)
        new_deadline = prompt_date("New Deadline", default=goal.deadline)
        new_prio = prompt_choice("New Priority", VALID_PRIORITIES, default=goal.priority)
        engine.update_goal(gid, target_amount=new_target, deadline=new_deadline, priority=new_prio)
        print(f"  {GREEN}✔ Goal {gid} updated.{RESET}")
    elif action == "d":
        confirm = input(f"  {RED}Confirm delete {gid} and its deposits? (yes/no): {RESET}").strip().lower()
        if confirm == "yes":
            engine.delete_goal(gid)
            print(f"  {GREEN}✔ Goal {gid} deleted.{RESET}")


def handle_executive_summary(engine: SavingsTrackerEngine, analytics: AnalyticsEngine) -> None:
    print(f"\n{CYAN}{BOLD}[6] Executive Summary & Threshold Warnings{RESET}")
    clear_divider()
    s = analytics.generate_executive_summary()

    print(f"  {BOLD}PORTFOLIO METRICS (as of {s['generated_at']}){RESET}")
    print(f"  • Total Goals Tracked      : {s['total_goals']}")
    print(f"  • Total Target Capital     : ${s['total_target']:,.2f}")
    print(f"  • Total Current Savings    : {GREEN}${s['total_saved']:,.2f}{RESET} ({s['overall_completion_pct']:.2f}%)")
    print(f"  • Remaining Shortfall      : ${s['total_remaining']:,.2f}")
    print(f"  • Total Deposits Logged    : {s['total_deposits_count']} (Avg: ${s['avg_deposit']:,.2f} | Max: ${s['max_deposit']:,.2f})")
    print(f"  • Top Savings Category     : {s['top_category']}")

    print(f"\n  {BOLD}STATUS DISTRIBUTION{RESET}")
    for st, count in s["status_counts"].items():
        print(f"    - {st:<18}: {count}")

    print(f"\n  {BOLD}CATEGORY BREAKDOWN{RESET}")
    print(f"  {'Category':<22} | {'Goals':>5} | {'Saved ($)':>14} | {'Target ($)':>14} | {'Comp%':>7}")
    print("  " + "-" * 74)
    for cat, stats in sorted(s["category_stats"].items()):
        print(
            f"  {cat:<22} | {stats['count']:>5} | ${stats['saved']:>13,.2f} | "
            f"${stats['target']:>13,.2f} | {stats['pct']:>6.1f}%"
        )

    alerts = engine.evaluate_threshold_warnings()
    print(f"\n  {BOLD}THRESHOLD WARNING INDICATORS ({len(alerts)} active){RESET}")
    if not alerts:
        print(f"  {GREEN}✔ All goals are within normal operating thresholds.{RESET}")
    else:
        for a in alerts[:12]:
            color = RED if a.severity == "CRITICAL" else (YELLOW if a.severity == "WARNING" else CYAN)
            print(f"  {color}[{a.severity:<8}] {a.goal_id} ({a.goal_title}): {a.message}{RESET}")
        if len(alerts) > 12:
            print(f"  {DIM}... and {len(alerts) - 12} more alerts (see full export report).{RESET}")


def handle_charts_and_exports(analytics: AnalyticsEngine, io_mgr: ReportExporterAndImporter) -> None:
    print(f"\n{CYAN}{BOLD}[7] Generate Matplotlib Charts & Multi-Format Reports{RESET}")
    clear_divider()
    charts, warning = analytics.generate_charts()
    if warning:
        print(f"  {YELLOW}⚠ {warning}{RESET}")
    for path in charts:
        print(f"  {GREEN}✔ Chart generated:{RESET} {path}")

    exports = io_mgr.export_all_formats()
    print(f"  {GREEN}✔ Markdown Executive Report:{RESET} {exports['markdown']}")
    print(f"  {GREEN}✔ Plain-Text Audit Log     :{RESET} {exports['audit_txt']}")
    print(f"  {GREEN}✔ Standardized CSV Report  :{RESET} {exports['csv']}")


def handle_bulk_import(io_mgr: ReportExporterAndImporter) -> None:
    print(f"\n{CYAN}{BOLD}[8] Bulk CSV Dataset Import{RESET}")
    clear_divider()
    print("  Expected CSV columns: title, category, target_amount, deadline (optional: goal_id, current_amount, priority, notes)")
    path = prompt_text("Enter path to CSV file", min_len=3, max_len=200)
    try:
        res = io_mgr.bulk_import_goals_csv(path)
        print(f"\n  {GREEN}✔ Successfully imported {res['imported_count']} goal(s).{RESET}")
        if res["failed_count"] > 0:
            print(f"  {YELLOW}⚠ Rejected {res['failed_count']} invalid row(s). Error log written to: {res['error_log_path']}{RESET}")
            for line in res["failed_details"][:5]:
                print(f"    {DIM}{line}{RESET}")
    except Exception as err:
        print(f"  {RED}[Import Error] {err}{RESET}")


def launch_streamlit_gui() -> None:
    print(f"\n{CYAN}{BOLD}[9] Launching Modern Streamlit Web GUI...{RESET}")
    print("  Press Ctrl+C in this terminal when you want to stop the web server.\n")
    try:
        subprocess.run([sys.executable, "-m", "streamlit", "run", "streamlit_app.py"], check=False)
    except Exception as err:
        print(f"  {RED}Unable to launch Streamlit automatically ({err}). Run manually via: streamlit run streamlit_app.py{RESET}")


def main() -> None:
    engine = SavingsTrackerEngine()
    analytics = AnalyticsEngine(engine)
    io_mgr = ReportExporterAndImporter(engine, analytics)

    print_banner()
    for msg in engine.startup_messages:
        print(f"  {YELLOW}[System]{RESET} {msg}")

    while True:
        print(f"\n{BOLD}MAIN MENU{RESET}")
        clear_divider()
        print("  1. Create New Savings Goal")
        print("  2. Record Savings Deposit")
        print("  3. View All Savings Goals (Paginated Table)")
        print("  4. Search & Filter Goals (Keyword / Category / Status)")
        print("  5. Inspect Goal Details / Update / Delete")
        print("  6. Executive Summary & Threshold Warning Indicators")
        print("  7. Generate Visual Charts (Matplotlib) & Export Reports (MD / TXT / CSV)")
        print("  8. Bulk Import Legacy CSV Dataset (with Row-by-Row Error Log)")
        print("  9. Launch Modern Streamlit GUI Dashboard")
        print("  0. Save & Exit")
        clear_divider()

        choice = input(f"  {BOLD}Select an option [0-9]: {RESET}").strip()

        if choice == "1":
            handle_create_goal(engine)
        elif choice == "2":
            handle_record_deposit(engine)
        elif choice == "3":
            render_paginated_goals_table(engine.get_all_enriched_goals(), page_size=10)
        elif choice == "4":
            handle_search_and_filter(engine)
        elif choice == "5":
            handle_goal_details_and_edit(engine)
        elif choice == "6":
            handle_executive_summary(engine, analytics)
        elif choice == "7":
            handle_charts_and_exports(analytics, io_mgr)
        elif choice == "8":
            handle_bulk_import(io_mgr)
        elif choice == "9":
            launch_streamlit_gui()
            engine.reload()
        elif choice == "0":
            engine.persist()
            print(f"\n  {GREEN}All records persisted to JSON & CSV. Goodbye!{RESET}\n")
            break
        else:
            print(f"  {RED}[Invalid Input] Please enter a menu number between 0 and 9.{RESET}")


if __name__ == "__main__":
    main()
