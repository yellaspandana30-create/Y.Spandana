# Savings Goal Tracker (GreenFuture Hack — Project #13)

A modular, fault-tolerant personal finance application featuring both an **interactive ANSI Terminal CLI** (`main.py`) and a **modern Streamlit Web Dashboard** (`streamlit_app.py`).

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the Modern Streamlit GUI (Recommended)
```bash
streamlit run streamlit_app.py
```

### 3. Run the Interactive Terminal CLI
```bash
python main.py
```
*(You can also launch the Streamlit GUI directly from Option `9` inside the terminal menu.)*

## Key Implemented Features
- **Interactive Terminal Interface (`main.py`)**: Menu-driven ANSI console workflow with fixed-width tables and pagination (`[N]ext / [P]rev / [Q]uit`).
- **Modern Streamlit Dashboard (`streamlit_app.py`)**: Real-time KPI metric cards, progress bars, interactive search/filter tables, goal/deposit forms, embedded Matplotlib charts, report downloads, and drag-and-drop bulk CSV import.
- **Defensive Input Validation (`src/validators.py`)**: Centralized regex, type, range, and calendar date checks preventing crashes from blank, malformed, or out-of-range inputs.
- **Core Business Logic Engine (`src/engine.py`)**: Computes completion percentages, remaining shortfalls, days remaining, required daily/monthly savings velocity, and schedule status (`On Track`, `Behind Schedule`, `At Risk`, `Overdue`, `Completed`).
- **Threshold Warning Indicators (`src/engine.py`)**: Automatically flags overdue goals, near-deadline shortfalls, overfunded targets, and anomalous high-value deposits (`>3x` average).
- **Fault-Tolerant Local Persistence (`src/storage.py`)**: Dual JSON (`data/savings_data.json`) and CSV (`data/savings_records.csv`) synchronization with automatic backup and recovery on missing or corrupted files.
- **Visual Data Plotting (`src/analytics.py`)**: High-DPI Matplotlib bar, dual-axis trend, and donut distribution charts saved to `exports/` with graceful `ImportError` fallback.
- **Multi-Format Export & Bulk CSV Import (`src/exporter.py`)**: Exports Markdown executive summaries (`.md`), plain-text audit logs (`.txt`), and standardized CSVs (`.csv`), plus bulk CSV ingestion with row-by-row error logging (testable with `data/sample_bulk_import.csv`).
