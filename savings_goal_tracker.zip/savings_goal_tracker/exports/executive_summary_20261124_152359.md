# Savings Goal Tracker — Executive Summary Report
**Generated:** 2026-11-24 15:23:59

## 1. Portfolio Overview
| Metric | Value |
| :--- | :--- |
| Total Active & Completed Goals | 24 |
| Total Target Capital | $156,750.00 |
| Total Current Savings | $110,709.99 |
| Total Remaining Shortfall | $46,250.01 |
| Overall Completion Rate | 70.63% |
| Total Recorded Deposits | 42 |
| Average Deposit Size | $2,657.86 |
| Top Funded Category | Home & Housing |

## 2. Category Breakdown
| Category | Goals | Target ($) | Saved ($) | Completion (%) |
| :--- | :---: | :---: | :---: | :---: |
| Education | 3 | $12,550.00 | $9,100.00 | 72.5% |
| Emergency Fund | 2 | $20,500.00 | $17,625.00 | 86.0% |
| Green Energy | 5 | $21,250.00 | $15,595.00 | 73.4% |
| Health & Wellness | 1 | $1,200.00 | $480.00 | 40.0% |
| Home & Housing | 3 | $53,400.00 | $33,950.00 | 63.6% |
| Other | 2 | $7,600.00 | $4,410.00 | 58.0% |
| Retirement & Wealth | 1 | $7,000.00 | $6,200.00 | 88.6% |
| Tech & Gear | 3 | $5,750.00 | $4,899.99 | 85.2% |
| Travel | 2 | $9,700.00 | $6,300.00 | 65.0% |
| Vehicle | 2 | $17,800.00 | $12,150.00 | 68.3% |

## 3. Threshold Warning Indicators
- **[CRITICAL] GOAL-107 (Heat Pump Water Heater):** Overdue by 25 day(s)! Still short by $2,650.00 (30.3% funded).
- **[CRITICAL] GOAL-119 (Marathon Training & Physio):** Overdue by 19 day(s)! Still short by $720.00 (40.0% funded).
- **[WARNING] GOAL-113 (Kitchen Appliance Refresh):** Actual progress (40.3%) trails expected pace (72.6%). Required monthly pace: $681.73.
- **[INFO] GOAL-104 (Home Down Payment Reserve):** Anomalous large deposit TX-1007 of $16,400.00 on 2026-02-14 (>3x avg $2,657.86).
- **[INFO] GOAL-104 (Home Down Payment Reserve):** Anomalous large deposit TX-1008 of $12,500.00 on 2026-08-19 (>3x avg $2,657.86).
- **[INFO] GOAL-108 (EV Charging Wallbox Setup):** Target exceeded by $150.00 (108.3% of goal).
- **[INFO] GOAL-122 (Holiday Family Gift Sinking Fund):** Target exceeded by $60.00 (103.8% of goal).

## 4. Detailed Goal Ledger
| ID | Title | Category | Priority | Saved / Target | Progress | Deadline | Status |
| :--- | :--- | :--- | :---: | :---: | :---: | :---: | :---: |
| GOAL-101 | 6-Month Family Emergency Fund | Emergency Fund | High | $15,750.00 / $18,000.00 | 87.5% | 2027-03-31 | On Track |
| GOAL-102 | Rooftop Solar Panel Array | Green Energy | High | $12,500.00 / $12,500.00 | 100.0% | 2026-10-15 | Completed |
| GOAL-103 | Master's Data Science Tuition | Education | High | $6,600.00 / $9,500.00 | 69.5% | 2027-05-01 | On Track |
| GOAL-104 | Home Down Payment Reserve | Home & Housing | High | $28,900.00 / $45,000.00 | 64.2% | 2028-01-15 | On Track |
| GOAL-105 | Kyoto & Osaka Autumn Trip | Travel | Medium | $4,200.00 / $4,200.00 | 100.0% | 2027-09-20 | Completed |
| GOAL-106 | Workstation & AI GPU Rig | Tech & Gear | Medium | $3,199.99 / $3,200.00 | 100.0% | 2026-12-15 | Completed |
| GOAL-107 | Heat Pump Water Heater | Green Energy | High | $1,150.00 / $3,800.00 | 30.3% | 2026-10-30 | Overdue |
| GOAL-108 | EV Charging Wallbox Setup | Vehicle | Low | $1,950.00 / $1,800.00 | 108.3% | 2026-09-01 | Completed |
| GOAL-110 | Index Fund Roth Contribution | Retirement & Wealth | High | $6,200.00 / $7,000.00 | 88.6% | 2027-04-15 | On Track |
| GOAL-111 | Rainwater Harvesting Cistern | Green Energy | Low | $0.00 / $2,400.00 | 0.0% | 2027-06-01 | On Track |
| GOAL-112 | Certified Cloud Architect Exam | Education | Medium | $850.00 / $850.00 | 100.0% | 2026-08-20 | Completed |
| GOAL-113 | Kitchen Appliance Refresh | Home & Housing | Medium | $1,450.00 / $3,600.00 | 40.3% | 2027-02-28 | Behind Schedule |
| GOAL-114 | Patagonia Trekking Expedition | Travel | Low | $2,100.00 / $5,500.00 | 38.2% | 2027-11-10 | On Track |
| GOAL-115 | Hybrid Commuter Vehicle Fund | Vehicle | High | $10,200.00 / $16,000.00 | 63.8% | 2027-08-30 | On Track |
| GOAL-116 | Home Ergonomic Standing Desk | Tech & Gear | Low | $1,100.00 / $1,100.00 | 100.0% | 2026-07-01 | Completed |
| GOAL-117 | Community Micro-Business Seed | Other | Medium | $2,750.00 / $6,000.00 | 45.8% | 2027-07-01 | On Track |
| GOAL-118 | Pet Emergency Vet Reserve | Emergency Fund | High | $1,875.00 / $2,500.00 | 75.0% | 2027-02-01 | On Track |
| GOAL-119 | Marathon Training & Physio | Health & Wellness | Low | $480.00 / $1,200.00 | 40.0% | 2026-11-05 | Overdue |
| GOAL-120 | Smart Home Energy Monitor | Green Energy | Low | $520.00 / $650.00 | 80.0% | 2027-01-15 | On Track |
| GOAL-121 | Summer Coding Bootcamp Mentor | Education | Medium | $1,650.00 / $2,200.00 | 75.0% | 2027-03-01 | On Track |
| GOAL-122 | Holiday Family Gift Sinking Fund | Other | Medium | $1,660.00 / $1,600.00 | 103.8% | 2026-12-20 | Completed |
| GOAL-123 | Backup Power Station (LiFePO4) | Green Energy | High | $1,425.00 / $1,900.00 | 75.0% | 2027-02-15 | On Track |
| GOAL-124 | Acoustic Guitar & Studio Mic | Tech & Gear | Low | $600.00 / $1,450.00 | 41.4% | 2027-06-30 | On Track |
| GOAL-125 | Property Tax Annual Escrow | Home & Housing | High | $3,600.00 / $4,800.00 | 75.0% | 2027-01-31 | On Track |
