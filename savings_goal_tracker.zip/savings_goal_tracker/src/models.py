"""Data models and schema definitions for Savings Goal Tracker."""

from dataclasses import dataclass, asdict
from datetime import date
from typing import Dict, Any


VALID_CATEGORIES = [
    "Emergency Fund",
    "Education",
    "Home & Housing",
    "Travel",
    "Tech & Gear",
    "Green Energy",
    "Vehicle",
    "Retirement & Wealth",
    "Health & Wellness",
    "Other",
]

VALID_PRIORITIES = ["High", "Medium", "Low"]


@dataclass
class DepositTransaction:
    """Represents a single deposit or adjustment entry toward a savings goal."""
    transaction_id: str
    goal_id: str
    amount: float
    transaction_date: str  # YYYY-MM-DD
    note: str = ""
    source: str = "Manual Entry"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DepositTransaction":
        return cls(
            transaction_id=str(data["transaction_id"]).strip(),
            goal_id=str(data["goal_id"]).strip(),
            amount=round(float(data["amount"]), 2),
            transaction_date=str(data["transaction_date"]).strip(),
            note=str(data.get("note", "")).strip(),
            source=str(data.get("source", "Manual Entry")).strip(),
        )


@dataclass
class SavingsGoal:
    """Represents a tracked savings goal with targets, deadlines, and metadata."""
    goal_id: str
    title: str
    category: str
    target_amount: float
    current_amount: float
    deadline: str  # YYYY-MM-DD
    created_date: str  # YYYY-MM-DD
    priority: str = "Medium"
    notes: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SavingsGoal":
        return cls(
            goal_id=str(data["goal_id"]).strip(),
            title=str(data["title"]).strip(),
            category=str(data["category"]).strip(),
            target_amount=round(float(data["target_amount"]), 2),
            current_amount=round(float(data.get("current_amount", 0.0)), 2),
            deadline=str(data["deadline"]).strip(),
            created_date=str(data.get("created_date", date.today().isoformat())).strip(),
            priority=str(data.get("priority", "Medium")).strip(),
            notes=str(data.get("notes", "")).strip(),
        )


@dataclass
class ThresholdAlert:
    """Represents an automated warning flag for overdue, at-risk, or anomalous records."""
    severity: str  # CRITICAL, WARNING, INFO
    code: str      # OVERDUE, BEHIND_SCHEDULE, ANOMALY_LARGE_DEPOSIT, OVERFUNDED
    goal_id: str
    goal_title: str
    message: str
