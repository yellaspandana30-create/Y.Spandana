"""Defensive input sanitization, regex checks, and interactive CLI input wrappers."""

import re
from datetime import datetime, date
from typing import Optional, List
from src.models import VALID_CATEGORIES, VALID_PRIORITIES

DATE_REGEX = re.compile(r"^\d{4}-\d{2}-\d{2}$")
GOAL_ID_REGEX = re.compile(r"^[A-Za-z0-9_-]{2,20}$")
SAFE_TEXT_REGEX = re.compile(r"^[\w\s.,!?&()'\-:/+$%#]+$")


class ValidationError(ValueError):
    """Raised when input data violates domain constraints."""


def sanitize_text(value: str, field_name: str = "Text", min_len: int = 1, max_len: int = 100, allow_empty: bool = False) -> str:
    """Strip whitespace, check length bounds, and reject control characters."""
    if value is None:
        if allow_empty:
            return ""
        raise ValidationError(f"{field_name} cannot be empty.")

    cleaned = " ".join(str(value).strip().split())
    if not cleaned:
        if allow_empty:
            return ""
        raise ValidationError(f"{field_name} cannot be blank or whitespace only.")

    if len(cleaned) < min_len:
        raise ValidationError(f"{field_name} must be at least {min_len} character(s).")
    if len(cleaned) > max_len:
        raise ValidationError(f"{field_name} cannot exceed {max_len} characters.")
    if not SAFE_TEXT_REGEX.match(cleaned):
        raise ValidationError(f"{field_name} contains unsupported special characters.")
    return cleaned


def validate_goal_id(goal_id: str) -> str:
    """Validate goal identifier format."""
    cleaned = str(goal_id or "").strip().upper()
    if not GOAL_ID_REGEX.match(cleaned):
        raise ValidationError("Goal ID must be 2-20 alphanumeric characters (letters, numbers, '-' or '_').")
    return cleaned


def validate_positive_amount(
    raw_value: str | float | int,
    field_name: str = "Amount",
    min_val: float = 0.01,
    max_val: float = 10_000_000.00,
    allow_zero: bool = False,
) -> float:
    """Parse currency/numeric strings safely and enforce domain range checks."""
    if raw_value is None or str(raw_value).strip() == "":
        raise ValidationError(f"{field_name} is required and cannot be blank.")

    cleaned = str(raw_value).strip().replace("$", "").replace(",", "")
    try:
        num = float(cleaned)
    except ValueError as exc:
        raise ValidationError(f"{field_name} must be a valid number (received '{raw_value}').") from exc

    if num != num or num in (float("inf"), float("-inf")):
        raise ValidationError(f"{field_name} must be a finite number.")

    effective_min = 0.0 if allow_zero else min_val
    if num < effective_min:
        if allow_zero:
            raise ValidationError(f"{field_name} cannot be negative (minimum {effective_min:.2f}).")
        raise ValidationError(f"{field_name} must be at least ${effective_min:,.2f}.")
    if num > max_val:
        raise ValidationError(f"{field_name} cannot exceed ${max_val:,.2f}.")

    return round(num, 2)


def validate_date_str(raw_date: str, field_name: str = "Date", must_be_future: bool = False) -> str:
    """Validate ISO YYYY-MM-DD format and calendar validity."""
    cleaned = str(raw_date or "").strip()
    if not DATE_REGEX.match(cleaned):
        raise ValidationError(f"{field_name} must follow YYYY-MM-DD format (e.g., 2026-12-31).")
    try:
        parsed = datetime.strptime(cleaned, "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValidationError(f"{field_name} '{cleaned}' is not a valid calendar date.") from exc

    if must_be_future and parsed < date.today():
        raise ValidationError(f"{field_name} ({cleaned}) cannot be in the past.")
    return parsed.isoformat()


def validate_category(raw_category: str) -> str:
    """Match category case-insensitively against allowed domain categories."""
    cleaned = str(raw_category or "").strip()
    for cat in VALID_CATEGORIES:
        if cat.lower() == cleaned.lower():
            return cat
    raise ValidationError(f"Invalid category '{raw_category}'. Allowed: {', '.join(VALID_CATEGORIES)}.")


def validate_priority(raw_priority: str) -> str:
    """Match priority case-insensitively against allowed priority levels."""
    cleaned = str(raw_priority or "").strip()
    for prio in VALID_PRIORITIES:
        if prio.lower() == cleaned.lower():
            return prio
    raise ValidationError(f"Invalid priority '{raw_priority}'. Allowed: {', '.join(VALID_PRIORITIES)}.")


# --- Interactive Terminal Input Wrappers ---

def prompt_text(
    label: str,
    min_len: int = 1,
    max_len: int = 100,
    allow_empty: bool = False,
    default: Optional[str] = None,
) -> str:
    """Loop until valid sanitized text is entered in CLI."""
    suffix = f" [{default}]" if default is not None else ""
    while True:
        raw = input(f"  {label}{suffix}: ")
        if raw.strip() == "" and default is not None:
            return default
        try:
            return sanitize_text(raw, field_name=label, min_len=min_len, max_len=max_len, allow_empty=allow_empty)
        except ValidationError as err:
            print(f"  \033[91m[Validation Error]\033[0m {err}")


def prompt_amount(
    label: str,
    min_val: float = 0.01,
    max_val: float = 10_000_000.00,
    allow_zero: bool = False,
    default: Optional[float] = None,
) -> float:
    """Loop until a valid bounded numeric amount is entered in CLI."""
    suffix = f" [{default:.2f}]" if default is not None else ""
    while True:
        raw = input(f"  {label}{suffix}: ")
        if raw.strip() == "" and default is not None:
            return round(default, 2)
        try:
            return validate_positive_amount(raw, field_name=label, min_val=min_val, max_val=max_val, allow_zero=allow_zero)
        except ValidationError as err:
            print(f"  \033[91m[Validation Error]\033[0m {err}")


def prompt_date(label: str, must_be_future: bool = False, default: Optional[str] = None) -> str:
    """Loop until a valid YYYY-MM-DD date is entered in CLI."""
    suffix = f" [{default}]" if default is not None else ""
    while True:
        raw = input(f"  {label} (YYYY-MM-DD){suffix}: ")
        if raw.strip() == "" and default is not None:
            return default
        try:
            return validate_date_str(raw, field_name=label, must_be_future=must_be_future)
        except ValidationError as err:
            print(f"  \033[91m[Validation Error]\033[0m {err}")


def prompt_choice(label: str, options: List[str], default: Optional[str] = None) -> str:
    """Display numbered options and loop until a valid index or exact name is chosen."""
    print(f"  {label}:")
    for idx, opt in enumerate(options, start=1):
        marker = " (default)" if default and opt == default else ""
        print(f"    {idx}. {opt}{marker}")

    while True:
        raw = input("  Select option number or name: ").strip()
        if raw == "" and default is not None:
            return default
        if raw.isdigit():
            idx = int(raw)
            if 1 <= idx <= len(options):
                return options[idx - 1]
        for opt in options:
            if opt.lower() == raw.lower():
                return opt
        print(f"  \033[91m[Validation Error]\033[0m Please enter a number between 1 and {len(options)} or a valid name.")
