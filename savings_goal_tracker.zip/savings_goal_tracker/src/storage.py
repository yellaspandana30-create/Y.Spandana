"""Fault-tolerant local persistence layer for JSON and CSV storage with schema recovery."""

import csv
import json
import os
import shutil
from datetime import datetime
from typing import Tuple, List, Dict, Any
from src.models import SavingsGoal, DepositTransaction
from src.validators import (
    validate_goal_id,
    sanitize_text,
    validate_category,
    validate_positive_amount,
    validate_date_str,
    validate_priority,
    ValidationError,
)


class StorageManager:
    """Handles reading/writing SavingsGoals and DepositTransactions to JSON and CSV."""

    def __init__(
        self,
        json_path: str = "data/savings_data.json",
        csv_path: str = "data/savings_records.csv",
        seed_json_path: str = "data/goals_seed.json",
        seed_csv_path: str = "data/deposits_seed.csv",
    ):
        self.json_path = json_path
        self.csv_path = csv_path
        self.seed_json_path = seed_json_path
        self.seed_csv_path = seed_csv_path
        os.makedirs(os.path.dirname(self.json_path) or ".", exist_ok=True)
        os.makedirs(os.path.dirname(self.csv_path) or ".", exist_ok=True)

    def _backup_corrupted_file(self, filepath: str) -> str:
        if os.path.exists(filepath):
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"{filepath}.corrupt_{ts}.bak"
            shutil.copy2(filepath, backup_path)
            return backup_path
        return ""

    def load_state(self) -> Tuple[List[SavingsGoal], List[DepositTransaction], List[str]]:
        """
        Load goals and transactions from JSON (and sync CSV).
        Automatically recovers from missing or corrupted files using seed data or clean templates.
        Returns (goals, transactions, system_messages).
        """
        messages: List[str] = []

        if not os.path.exists(self.json_path):
            if os.path.exists(self.seed_json_path):
                shutil.copy2(self.seed_json_path, self.json_path)
                messages.append("Initialized local JSON storage from pre-seeded dataset.")
            else:
                self._write_clean_template()
                messages.append("Initialized clean empty JSON/CSV storage templates.")

        try:
            with open(self.json_path, "r", encoding="utf-8") as f:
                raw_data = json.load(f)
        except (json.JSONDecodeError, OSError) as err:
            backup = self._backup_corrupted_file(self.json_path)
            messages.append(f"Corrupted JSON detected ({err}). Backed up to {backup} and reset storage.")
            if os.path.exists(self.seed_json_path):
                shutil.copy2(self.seed_json_path, self.json_path)
            else:
                self._write_clean_template()
            with open(self.json_path, "r", encoding="utf-8") as f:
                raw_data = json.load(f)

        if not isinstance(raw_data, dict) or "goals" not in raw_data:
            backup = self._backup_corrupted_file(self.json_path)
            messages.append(f"Invalid JSON schema detected. Backed up to {backup} and restored template.")
            self._write_clean_template()
            raw_data = {"goals": [], "transactions": []}

        goals: List[SavingsGoal] = []
        seen_goal_ids = set()
        for idx, item in enumerate(raw_data.get("goals", [])):
            try:
                gid = validate_goal_id(item.get("goal_id", ""))
                if gid in seen_goal_ids:
                    continue
                goal = SavingsGoal(
                    goal_id=gid,
                    title=sanitize_text(item.get("title", ""), "Title", max_len=80),
                    category=validate_category(item.get("category", "Other")),
                    target_amount=validate_positive_amount(item.get("target_amount", 0), "Target Amount"),
                    current_amount=validate_positive_amount(item.get("current_amount", 0), "Current Amount", allow_zero=True),
                    deadline=validate_date_str(item.get("deadline", ""), "Deadline"),
                    created_date=validate_date_str(item.get("created_date", datetime.today().strftime("%Y-%m-%d")), "Created Date"),
                    priority=validate_priority(item.get("priority", "Medium")),
                    notes=sanitize_text(item.get("notes", ""), "Notes", max_len=200, allow_empty=True),
                )
                goals.append(goal)
                seen_goal_ids.add(gid)
            except (ValidationError, KeyError, TypeError, ValueError) as e:
                messages.append(f"Skipped malformed goal record at index {idx}: {e}")

        transactions: List[DepositTransaction] = []
        if not os.path.exists(self.csv_path) and os.path.exists(self.seed_csv_path) and not raw_data.get("transactions"):
            shutil.copy2(self.seed_csv_path, self.csv_path)

        raw_txs = raw_data.get("transactions", [])
        if not raw_txs and os.path.exists(self.csv_path):
            raw_txs = self._read_transactions_csv(messages)

        for idx, tx_item in enumerate(raw_txs):
            try:
                tx = DepositTransaction(
                    transaction_id=sanitize_text(tx_item.get("transaction_id", ""), "Transaction ID", max_len=30),
                    goal_id=validate_goal_id(tx_item.get("goal_id", "")),
                    amount=validate_positive_amount(tx_item.get("amount", 0), "Deposit Amount"),
                    transaction_date=validate_date_str(tx_item.get("transaction_date", ""), "Transaction Date"),
                    note=sanitize_text(tx_item.get("note", ""), "Note", max_len=150, allow_empty=True),
                    source=sanitize_text(tx_item.get("source", "Manual Entry"), "Source", max_len=50, allow_empty=True) or "Manual Entry",
                )
                transactions.append(tx)
            except (ValidationError, KeyError, TypeError, ValueError) as e:
                messages.append(f"Skipped malformed deposit record at index {idx}: {e}")

        self.save_state(goals, transactions)
        return goals, transactions, messages

    def _read_transactions_csv(self, messages: List[str]) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        try:
            with open(self.csv_path, "r", encoding="utf-8", newline="") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    rows.append(dict(row))
        except (csv.Error, OSError) as err:
            messages.append(f"Warning reading CSV ledger: {err}")
        return rows

    def _write_clean_template(self) -> None:
        empty_payload = {
            "schema_version": "1.0",
            "last_updated": datetime.now().isoformat(),
            "goals": [],
            "transactions": [],
        }
        with open(self.json_path, "w", encoding="utf-8") as f:
            json.dump(empty_payload, f, indent=2)
        self._write_csv([], [])

    def save_state(self, goals: List[SavingsGoal], transactions: List[DepositTransaction]) -> None:
        """Persist complete application state atomically to both JSON and CSV."""
        payload = {
            "schema_version": "1.0",
            "last_updated": datetime.now().isoformat(),
            "goals": [g.to_dict() for g in goals],
            "transactions": [t.to_dict() for t in transactions],
        }
        tmp_json = f"{self.json_path}.tmp"
        with open(tmp_json, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        os.replace(tmp_json, self.json_path)

        self._write_csv(goals, transactions)

    def _write_csv(self, goals: List[SavingsGoal], transactions: List[DepositTransaction]) -> None:
        """Write normalized transaction ledger CSV and goal snapshot CSV."""
        tx_fieldnames = ["transaction_id", "goal_id", "amount", "transaction_date", "note", "source"]
        with open(self.csv_path, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=tx_fieldnames)
            writer.writeheader()
            for tx in transactions:
                writer.writerow(tx.to_dict())

        goals_snapshot_path = self.csv_path.replace("savings_records.csv", "savings_goals_snapshot.csv")
        if goals_snapshot_path == self.csv_path:
            goals_snapshot_path = "data/savings_goals_snapshot.csv"
        goal_fieldnames = [
            "goal_id", "title", "category", "target_amount",
            "current_amount", "deadline", "created_date", "priority", "notes"
        ]
        with open(goals_snapshot_path, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=goal_fieldnames)
            writer.writeheader()
            for g in goals:
                writer.writerow(g.to_dict())
