"""Multi-format report exporter (Markdown, TXT audit log, CSV) and Bulk CSV dataset importer."""

import csv
import os
from datetime import datetime
from typing import Dict, Any, List
from src.engine import SavingsTrackerEngine
from src.analytics import AnalyticsEngine
from src.validators import (
    validate_goal_id,
    ValidationError,
)


class ReportExporterAndImporter:
    """Handles multi-format executive exports and validated bulk CSV dataset ingestion."""

    def __init__(self, engine: SavingsTrackerEngine, analytics: AnalyticsEngine, export_dir: str = "exports"):
        self.engine = engine
        self.analytics = analytics
        self.export_dir = export_dir
        os.makedirs(self.export_dir, exist_ok=True)

    def export_markdown_report(self) -> str:
        """Generate a structured Markdown executive summary report."""
        summary = self.analytics.generate_executive_summary()
        enriched = self.engine.get_all_enriched_goals()
        alerts = self.engine.evaluate_threshold_warnings()
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(self.export_dir, f"executive_summary_{ts}.md")

        lines = [
            "# Savings Goal Tracker — Executive Summary Report",
            f"**Generated:** {summary['generated_at']}",
            "",
            "## 1. Portfolio Overview",
            "| Metric | Value |",
            "| :--- | :--- |",
            f"| Total Active & Completed Goals | {summary['total_goals']} |",
            f"| Total Target Capital | ${summary['total_target']:,.2f} |",
            f"| Total Current Savings | ${summary['total_saved']:,.2f} |",
            f"| Total Remaining Shortfall | ${summary['total_remaining']:,.2f} |",
            f"| Overall Completion Rate | {summary['overall_completion_pct']:.2f}% |",
            f"| Total Recorded Deposits | {summary['total_deposits_count']} |",
            f"| Average Deposit Size | ${summary['avg_deposit']:,.2f} |",
            f"| Top Funded Category | {summary['top_category']} |",
            "",
            "## 2. Category Breakdown",
            "| Category | Goals | Target ($) | Saved ($) | Completion (%) |",
            "| :--- | :---: | :---: | :---: | :---: |",
        ]
        for cat, stats in sorted(summary["category_stats"].items()):
            lines.append(
                f"| {cat} | {stats['count']} | ${stats['target']:,.2f} | ${stats['saved']:,.2f} | {stats['pct']:.1f}% |"
            )

        lines.extend([
            "",
            "## 3. Threshold Warning Indicators",
        ])
        if not alerts:
            lines.append("- No active threshold warnings or anomalies detected.")
        else:
            for alert in alerts:
                lines.append(f"- **[{alert.severity}] {alert.goal_id} ({alert.goal_title}):** {alert.message}")

        lines.extend([
            "",
            "## 4. Detailed Goal Ledger",
            "| ID | Title | Category | Priority | Saved / Target | Progress | Deadline | Status |",
            "| :--- | :--- | :--- | :---: | :---: | :---: | :---: | :---: |",
        ])
        for g in enriched:
            lines.append(
                f"| {g['goal_id']} | {g['title']} | {g['category']} | {g['priority']} | "
                f"${g['current_amount']:,.2f} / ${g['target_amount']:,.2f} | {g['progress_pct']:.1f}% | "
                f"{g['deadline']} | {g['status']} |"
            )

        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        return filepath

    def export_plain_text_audit_log(self) -> str:
        """Generate a plain-text chronological audit log of goals, alerts, and transactions."""
        summary = self.analytics.generate_executive_summary()
        alerts = self.engine.evaluate_threshold_warnings()
        txs = self.engine.get_goal_transactions()
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(self.export_dir, f"audit_log_{ts}.txt")

        lines = [
            "=" * 78,
            "SAVINGS GOAL TRACKER — SYSTEM AUDIT & COMPLIANCE LOG",
            f"Timestamp : {summary['generated_at']}",
            f"Goals     : {summary['total_goals']} | Deposits: {summary['total_deposits_count']}",
            f"Saved     : ${summary['total_saved']:,.2f} / ${summary['total_target']:,.2f} ({summary['overall_completion_pct']:.2f}%)",
            "=" * 78,
            "",
            "[SECTION 1: THRESHOLD WARNINGS & ANOMALY FLAGS]",
        ]
        if not alerts:
            lines.append("  OK - Zero threshold breaches detected.")
        else:
            for a in alerts:
                lines.append(f"  [{a.severity:<8}] [{a.code:<21}] {a.goal_id}: {a.message}")

        lines.extend([
            "",
            "[SECTION 2: CHRONOLOGICAL DEPOSIT AUDIT TRAIL]",
        ])
        for t in txs:
            lines.append(
                f"  {t.transaction_date} | {t.transaction_id:<8} | {t.goal_id:<10} | "
                f"${t.amount:>10,.2f} | {t.source:<16} | {t.note}"
            )

        lines.append("=" * 78)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        return filepath

    def export_standardized_csv(self) -> str:
        """Export standardized enriched goal report CSV for spreadsheet review."""
        enriched = self.engine.get_all_enriched_goals()
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(self.export_dir, f"goals_standardized_report_{ts}.csv")

        fieldnames = [
            "goal_id", "title", "category", "priority", "target_amount",
            "current_amount", "remaining_amount", "progress_pct", "expected_pct",
            "deadline", "days_remaining", "required_daily", "required_monthly",
            "deposit_count", "avg_deposit", "status", "notes"
        ]
        with open(filepath, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in enriched:
                filtered = {k: row[k] for k in fieldnames}
                writer.writerow(filtered)
        return filepath

    def export_all_formats(self) -> Dict[str, str]:
        """Generate Markdown, Plain-Text Audit Log, and Standardized CSV in one batch."""
        return {
            "markdown": self.export_markdown_report(),
            "audit_txt": self.export_plain_text_audit_log(),
            "csv": self.export_standardized_csv(),
        }

    # --- Stretch Feature: Bulk Dataset Import with Row-by-Row Validation Log ---

    def bulk_import_goals_csv(self, csv_filepath: str) -> Dict[str, Any]:
        """
        Ingest an external/legacy CSV of savings goals with strict row-by-row validation.
        Expected columns: goal_id (optional), title, category, target_amount, current_amount (optional),
        deadline, created_date (optional), priority (optional), notes (optional).
        Writes a detailed error log file if any rows fail validation.
        """
        if not os.path.exists(csv_filepath):
            raise FileNotFoundError(f"Import file not found: {csv_filepath}")

        imported_count = 0
        failed_rows: List[str] = []

        with open(csv_filepath, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            if not reader.fieldnames:
                raise ValidationError("CSV file is empty or missing header row.")

            required_cols = {"title", "category", "target_amount", "deadline"}
            normalized_headers = {h.strip().lower() for h in reader.fieldnames if h}
            missing = required_cols - normalized_headers
            if missing:
                raise ValidationError(f"Missing required CSV columns: {', '.join(sorted(missing))}")

            for row_num, raw_row in enumerate(reader, start=2):
                row = {k.strip().lower(): (v.strip() if v is not None else "") for k, v in raw_row.items() if k}
                try:
                    raw_gid = row.get("goal_id", "")
                    gid = validate_goal_id(raw_gid) if raw_gid else None
                    self.engine.add_goal(
                        title=row.get("title", ""),
                        category=row.get("category", ""),
                        target_amount=row.get("target_amount", ""),
                        deadline=row.get("deadline", ""),
                        initial_amount=row.get("current_amount") or "0",
                        priority=row.get("priority") or "Medium",
                        notes=row.get("notes", ""),
                        goal_id=gid,
                        created_date=row.get("created_date") or None,
                    )
                    imported_count += 1
                except Exception as err:
                    failed_rows.append(f"Row {row_num}: {err} | Raw Data: {dict(row)}")

        error_log_path = None
        if failed_rows:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            error_log_path = os.path.join(self.export_dir, f"bulk_import_errors_{ts}.log")
            with open(error_log_path, "w", encoding="utf-8") as ef:
                ef.write(f"BULK IMPORT VALIDATION LOG ({datetime.now().isoformat()})\n")
                ef.write(f"Source File: {csv_filepath}\n")
                ef.write(f"Imported: {imported_count} | Rejected: {len(failed_rows)}\n")
                ef.write("-" * 72 + "\n")
                for line in failed_rows:
                    ef.write(line + "\n")

        return {
            "imported_count": imported_count,
            "failed_count": len(failed_rows),
            "failed_details": failed_rows,
            "error_log_path": error_log_path,
        }
