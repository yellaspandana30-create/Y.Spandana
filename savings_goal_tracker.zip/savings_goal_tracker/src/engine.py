"""Core business logic engine for tracking savings targets, deposits, progress, and alerts."""

from datetime import datetime, date
from typing import List, Dict, Any, Optional, Tuple
from src.models import SavingsGoal, DepositTransaction, ThresholdAlert
from src.storage import StorageManager
from src.validators import (
    validate_goal_id,
    sanitize_text,
    validate_category,
    validate_positive_amount,
    validate_date_str,
    validate_priority,
    ValidationError,
)


class SavingsTrackerEngine:
    """Encapsulates all CRUD, computational progress metrics, search, and warning logic."""

    def __init__(self, storage: Optional[StorageManager] = None):
        self.storage = storage or StorageManager()
        self.goals, self.transactions, self.startup_messages = self.storage.load_state()

    def reload(self) -> List[str]:
        self.goals, self.transactions, msgs = self.storage.load_state()
        return msgs

    def persist(self) -> None:
        self.storage.save_state(self.goals, self.transactions)

    # --- Computational Metrics for Individual Goals ---

    def compute_goal_metrics(self, goal: SavingsGoal, ref_date: Optional[date] = None) -> Dict[str, Any]:
        """Calculate completion %, remaining balance, days left, required monthly pace, and status."""
        today = ref_date or date.today()
        deadline_dt = datetime.strptime(goal.deadline, "%Y-%m-%d").date()
        created_dt = datetime.strptime(goal.created_date, "%Y-%m-%d").date()

        remaining = max(0.0, round(goal.target_amount - goal.current_amount, 2))
        overfunded_by = max(0.0, round(goal.current_amount - goal.target_amount, 2))
        pct = round((goal.current_amount / goal.target_amount) * 100.0, 2) if goal.target_amount > 0 else 0.0

        days_remaining = (deadline_dt - today).days
        total_span_days = max(1, (deadline_dt - created_dt).days)
        elapsed_days = max(0, (today - created_dt).days)
        expected_pct = min(100.0, round((elapsed_days / total_span_days) * 100.0, 2))

        if pct >= 100.0:
            status = "Completed"
            required_daily = 0.0
            required_monthly = 0.0
        elif days_remaining < 0:
            status = "Overdue"
            required_daily = remaining
            required_monthly = remaining
        else:
            effective_days = max(1, days_remaining)
            required_daily = round(remaining / effective_days, 2)
            required_monthly = round(remaining / max(1.0, effective_days / 30.44), 2)
            if days_remaining <= 30 and pct < 75.0:
                status = "At Risk"
            elif pct + 15.0 < expected_pct:
                status = "Behind Schedule"
            else:
                status = "On Track"

        goal_txs = [t for t in self.transactions if t.goal_id == goal.goal_id]
        avg_deposit = round(sum(t.amount for t in goal_txs) / len(goal_txs), 2) if goal_txs else 0.0

        return {
            "goal_id": goal.goal_id,
            "title": goal.title,
            "category": goal.category,
            "priority": goal.priority,
            "target_amount": goal.target_amount,
            "current_amount": goal.current_amount,
            "remaining_amount": remaining,
            "overfunded_by": overfunded_by,
            "progress_pct": pct,
            "expected_pct": expected_pct,
            "deadline": goal.deadline,
            "created_date": goal.created_date,
            "days_remaining": days_remaining,
            "required_daily": required_daily,
            "required_monthly": required_monthly,
            "deposit_count": len(goal_txs),
            "avg_deposit": avg_deposit,
            "status": status,
            "notes": goal.notes,
        }

    def get_all_enriched_goals(self) -> List[Dict[str, Any]]:
        return [self.compute_goal_metrics(g) for g in self.goals]

    def get_goal_by_id(self, goal_id: str) -> Optional[SavingsGoal]:
        target_id = goal_id.strip().upper()
        for g in self.goals:
            if g.goal_id.upper() == target_id:
                return g
        return None

    def generate_next_goal_id(self) -> str:
        existing_nums = []
        for g in self.goals:
            if g.goal_id.startswith("GOAL-"):
                suffix = g.goal_id.split("-", 1)[1]
                if suffix.isdigit():
                    existing_nums.append(int(suffix))
        next_num = (max(existing_nums) + 1) if existing_nums else 101
        return f"GOAL-{next_num:03d}"

    def generate_next_tx_id(self) -> str:
        existing_nums = []
        for t in self.transactions:
            if t.transaction_id.startswith("TX-"):
                suffix = t.transaction_id.split("-", 1)[1]
                if suffix.isdigit():
                    existing_nums.append(int(suffix))
        next_num = (max(existing_nums) + 1) if existing_nums else 1001
        return f"TX-{next_num:04d}"

    # --- CRUD Operations ---

    def add_goal(
        self,
        title: str,
        category: str,
        target_amount: float | str,
        deadline: str,
        initial_amount: float | str = 0.0,
        priority: str = "Medium",
        notes: str = "",
        goal_id: Optional[str] = None,
        created_date: Optional[str] = None,
    ) -> Tuple[SavingsGoal, List[str]]:
        """Validate inputs, create a new SavingsGoal, record initial deposit if > 0, and persist."""
        gid = validate_goal_id(goal_id) if goal_id else self.generate_next_goal_id()
        if self.get_goal_by_id(gid) is not None:
            raise ValidationError(f"Goal ID '{gid}' already exists.")

        clean_title = sanitize_text(title, "Goal Title", min_len=2, max_len=80)
        clean_cat = validate_category(category)
        clean_target = validate_positive_amount(target_amount, "Target Amount", min_val=1.00)
        clean_initial = validate_positive_amount(initial_amount, "Initial Deposit", allow_zero=True)
        clean_deadline = validate_date_str(deadline, "Deadline")
        clean_created = validate_date_str(created_date, "Created Date") if created_date else date.today().isoformat()
        clean_prio = validate_priority(priority)
        clean_notes = sanitize_text(notes, "Notes", max_len=200, allow_empty=True)

        goal = SavingsGoal(
            goal_id=gid,
            title=clean_title,
            category=clean_cat,
            target_amount=clean_target,
            current_amount=clean_initial,
            deadline=clean_deadline,
            created_date=clean_created,
            priority=clean_prio,
            notes=clean_notes,
        )
        self.goals.append(goal)

        warnings: List[str] = []
        if clean_initial > 0:
            tx = DepositTransaction(
                transaction_id=self.generate_next_tx_id(),
                goal_id=gid,
                amount=clean_initial,
                transaction_date=clean_created,
                note="Initial opening deposit",
                source="Goal Creation",
            )
            self.transactions.append(tx)
            if clean_initial > clean_target:
                warnings.append(f"Initial deposit (${clean_initial:,.2f}) exceeds target (${clean_target:,.2f}).")

        self.persist()
        return goal, warnings

    def record_deposit(
        self,
        goal_id: str,
        amount: float | str,
        transaction_date: Optional[str] = None,
        note: str = "",
        source: str = "Manual Entry",
    ) -> Tuple[DepositTransaction, SavingsGoal, List[str]]:
        """Log a validated deposit toward an existing goal, update balance, and detect anomalies."""
        goal = self.get_goal_by_id(goal_id)
        if goal is None:
            raise ValidationError(f"No savings goal found with ID '{goal_id}'.")

        clean_amt = validate_positive_amount(amount, "Deposit Amount", min_val=0.01)
        clean_date = validate_date_str(transaction_date, "Deposit Date") if transaction_date else date.today().isoformat()
        clean_note = sanitize_text(note, "Deposit Note", max_len=150, allow_empty=True)
        clean_source = sanitize_text(source, "Source", max_len=50, allow_empty=True) or "Manual Entry"

        warnings: List[str] = []
        remaining_before = max(0.0, goal.target_amount - goal.current_amount)
        if clean_amt > remaining_before and remaining_before > 0:
            warnings.append(
                f"Anomaly Notice: Deposit (${clean_amt:,.2f}) exceeds remaining target balance (${remaining_before:,.2f}). Goal is now overfunded."
            )
        elif remaining_before == 0:
            warnings.append(f"Notice: Goal '{goal.title}' was already 100% funded prior to this deposit.")

        if self.transactions:
            global_avg = sum(t.amount for t in self.transactions) / len(self.transactions)
            if global_avg > 0 and clean_amt > global_avg * 3.0:
                warnings.append(
                    f"High-Value Anomaly: Deposit (${clean_amt:,.2f}) is >3x the historical average (${global_avg:,.2f})."
                )

        tx = DepositTransaction(
            transaction_id=self.generate_next_tx_id(),
            goal_id=goal.goal_id,
            amount=clean_amt,
            transaction_date=clean_date,
            note=clean_note,
            source=clean_source,
        )
        goal.current_amount = round(goal.current_amount + clean_amt, 2)
        self.transactions.append(tx)
        self.persist()
        return tx, goal, warnings

    def update_goal(
        self,
        goal_id: str,
        title: Optional[str] = None,
        category: Optional[str] = None,
        target_amount: Optional[float | str] = None,
        deadline: Optional[str] = None,
        priority: Optional[str] = None,
        notes: Optional[str] = None,
    ) -> SavingsGoal:
        """Update editable attributes of an existing savings goal."""
        goal = self.get_goal_by_id(goal_id)
        if goal is None:
            raise ValidationError(f"No savings goal found with ID '{goal_id}'.")

        if title is not None:
            goal.title = sanitize_text(title, "Goal Title", min_len=2, max_len=80)
        if category is not None:
            goal.category = validate_category(category)
        if target_amount is not None:
            goal.target_amount = validate_positive_amount(target_amount, "Target Amount", min_val=1.00)
        if deadline is not None:
            goal.deadline = validate_date_str(deadline, "Deadline")
        if priority is not None:
            goal.priority = validate_priority(priority)
        if notes is not None:
            goal.notes = sanitize_text(notes, "Notes", max_len=200, allow_empty=True)

        self.persist()
        return goal

    def delete_goal(self, goal_id: str, delete_transactions: bool = True) -> bool:
        """Delete a goal and optionally its associated deposit transactions."""
        goal = self.get_goal_by_id(goal_id)
        if goal is None:
            return False
        self.goals = [g for g in self.goals if g.goal_id != goal.goal_id]
        if delete_transactions:
            self.transactions = [t for t in self.transactions if t.goal_id != goal.goal_id]
        self.persist()
        return True

    # --- Query & Search ---

    def search_goals(
        self,
        keyword: str = "",
        category: str = "All",
        status: str = "All",
        priority: str = "All",
    ) -> List[Dict[str, Any]]:
        """Filter enriched goals by keyword, category, calculated status, and priority."""
        kw = keyword.strip().lower()
        results: List[Dict[str, Any]] = []
        for g in self.goals:
            metrics = self.compute_goal_metrics(g)
            if kw and kw not in g.title.lower() and kw not in g.notes.lower() and kw not in g.goal_id.lower():
                continue
            if category and category != "All" and g.category.lower() != category.lower():
                continue
            if status and status != "All" and metrics["status"].lower() != status.lower():
                continue
            if priority and priority != "All" and g.priority.lower() != priority.lower():
                continue
            results.append(metrics)
        return results

    def get_goal_transactions(self, goal_id: Optional[str] = None) -> List[DepositTransaction]:
        txs = self.transactions
        if goal_id:
            gid = goal_id.strip().upper()
            txs = [t for t in txs if t.goal_id.upper() == gid]
        return sorted(txs, key=lambda x: (x.transaction_date, x.transaction_id), reverse=True)

    # --- Stretch Feature: Threshold Warning Indicators ---

    def evaluate_threshold_warnings(self, ref_date: Optional[date] = None) -> List[ThresholdAlert]:
        """Scan all goals and transactions for overdue deadlines, at-risk schedules, and anomalies."""
        alerts: List[ThresholdAlert] = []
        enriched = self.get_all_enriched_goals()

        for m in enriched:
            if m["status"] == "Overdue":
                alerts.append(
                    ThresholdAlert(
                        severity="CRITICAL",
                        code="OVERDUE",
                        goal_id=m["goal_id"],
                        goal_title=m["title"],
                        message=f"Overdue by {abs(m['days_remaining'])} day(s)! Still short by ${m['remaining_amount']:,.2f} ({m['progress_pct']:.1f}% funded).",
                    )
                )
            elif m["status"] == "At Risk":
                alerts.append(
                    ThresholdAlert(
                        severity="WARNING",
                        code="DEADLINE_PROXIMITY",
                        goal_id=m["goal_id"],
                        goal_title=m["title"],
                        message=f"Due in {m['days_remaining']} day(s) with only {m['progress_pct']:.1f}% funded. Needs ${m['required_daily']:,.2f}/day.",
                    )
                )
            elif m["status"] == "Behind Schedule":
                alerts.append(
                    ThresholdAlert(
                        severity="WARNING",
                        code="BEHIND_SCHEDULE",
                        goal_id=m["goal_id"],
                        goal_title=m["title"],
                        message=f"Actual progress ({m['progress_pct']:.1f}%) trails expected pace ({m['expected_pct']:.1f}%). Required monthly pace: ${m['required_monthly']:,.2f}.",
                    )
                )

            if m["overfunded_by"] > 0:
                alerts.append(
                    ThresholdAlert(
                        severity="INFO",
                        code="OVERFUNDED",
                        goal_id=m["goal_id"],
                        goal_title=m["title"],
                        message=f"Target exceeded by ${m['overfunded_by']:,.2f} ({m['progress_pct']:.1f}% of goal).",
                    )
                )

        if self.transactions:
            avg_tx = sum(t.amount for t in self.transactions) / len(self.transactions)
            threshold = max(1000.0, avg_tx * 3.0)
            goal_lookup = {g.goal_id: g.title for g in self.goals}
            for tx in self.transactions:
                if tx.amount > threshold:
                    alerts.append(
                        ThresholdAlert(
                            severity="INFO",
                            code="ANOMALY_LARGE_DEPOSIT",
                            goal_id=tx.goal_id,
                            goal_title=goal_lookup.get(tx.goal_id, tx.goal_id),
                            message=f"Anomalous large deposit {tx.transaction_id} of ${tx.amount:,.2f} on {tx.transaction_date} (>3x avg ${avg_tx:,.2f}).",
                        )
                    )

        severity_order = {"CRITICAL": 0, "WARNING": 1, "INFO": 2}
        alerts.sort(key=lambda a: (severity_order.get(a.severity, 3), a.goal_id))
        return alerts
