"""Executive summary statistics and Matplotlib visual reporting with graceful fallback."""

import os
from collections import defaultdict
from datetime import datetime
from typing import Dict, Any, List, Tuple, Optional
from src.engine import SavingsTrackerEngine

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    plt = None
    MATPLOTLIB_AVAILABLE = False


class AnalyticsEngine:
    """Computes executive KPIs, category breakdowns, monthly trends, and Matplotlib charts."""

    def __init__(self, engine: SavingsTrackerEngine, export_dir: str = "exports"):
        self.engine = engine
        self.export_dir = export_dir
        os.makedirs(self.export_dir, exist_ok=True)

    def generate_executive_summary(self) -> Dict[str, Any]:
        """Aggregate portfolio-wide savings KPIs, category distributions, and monthly deposit velocity."""
        enriched = self.engine.get_all_enriched_goals()
        txs = self.engine.transactions

        total_goals = len(enriched)
        total_target = round(sum(g["target_amount"] for g in enriched), 2)
        total_saved = round(sum(g["current_amount"] for g in enriched), 2)
        total_remaining = round(sum(g["remaining_amount"] for g in enriched), 2)
        overall_completion_pct = round((total_saved / total_target) * 100.0, 2) if total_target > 0 else 0.0

        status_counts: Dict[str, int] = defaultdict(int)
        category_stats: Dict[str, Dict[str, float]] = defaultdict(lambda: {"target": 0.0, "saved": 0.0, "count": 0})

        for g in enriched:
            status_counts[g["status"]] += 1
            cat = g["category"]
            category_stats[cat]["target"] = round(category_stats[cat]["target"] + g["target_amount"], 2)
            category_stats[cat]["saved"] = round(category_stats[cat]["saved"] + g["current_amount"], 2)
            category_stats[cat]["count"] += 1

        for cat, data in category_stats.items():
            data["pct"] = round((data["saved"] / data["target"]) * 100.0, 2) if data["target"] > 0 else 0.0

        total_deposits_count = len(txs)
        total_deposited_volume = round(sum(t.amount for t in txs), 2)
        avg_deposit = round(total_deposited_volume / total_deposits_count, 2) if total_deposits_count > 0 else 0.0
        max_deposit = max((t.amount for t in txs), default=0.0)
        min_deposit = min((t.amount for t in txs), default=0.0)

        monthly_deposits: Dict[str, float] = defaultdict(float)
        for t in sorted(txs, key=lambda x: x.transaction_date):
            ym = t.transaction_date[:7]
            monthly_deposits[ym] = round(monthly_deposits[ym] + t.amount, 2)

        cumulative_trend: List[Tuple[str, float, float]] = []
        running = 0.0
        for ym in sorted(monthly_deposits.keys()):
            amt = monthly_deposits[ym]
            running = round(running + amt, 2)
            cumulative_trend.append((ym, amt, running))

        top_category = None
        if category_stats:
            top_category = max(category_stats.items(), key=lambda item: item[1]["saved"])[0]

        alerts = self.engine.evaluate_threshold_warnings()

        return {
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_goals": total_goals,
            "total_target": total_target,
            "total_saved": total_saved,
            "total_remaining": total_remaining,
            "overall_completion_pct": overall_completion_pct,
            "status_counts": dict(status_counts),
            "category_stats": dict(category_stats),
            "top_category": top_category or "N/A",
            "total_deposits_count": total_deposits_count,
            "total_deposited_volume": total_deposited_volume,
            "avg_deposit": avg_deposit,
            "max_deposit": round(max_deposit, 2),
            "min_deposit": round(min_deposit, 2),
            "monthly_trend": cumulative_trend,
            "alert_count": len(alerts),
            "critical_alert_count": sum(1 for a in alerts if a.severity == "CRITICAL"),
        }

    def generate_charts(self, prefix: str = "savings_report") -> Tuple[List[str], Optional[str]]:
        """
        Generate 3 Matplotlib PNG visual reports:
        1. Goal Progress vs. Target Bar Chart
        2. Cumulative Savings Trend Line Chart
        3. Category Allocation Distribution Chart
        Returns (list_of_saved_paths, warning_or_none).
        """
        if not MATPLOTLIB_AVAILABLE:
            return [], "Matplotlib is not installed in this environment. Visual charts skipped gracefully."

        enriched = self.engine.get_all_enriched_goals()
        summary = self.generate_executive_summary()
        if not enriched:
            return [], "No savings goals available to plot."

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        saved_files: List[str] = []

        # --- Chart 1: Top Goals Progress vs Target ---
        sorted_goals = sorted(enriched, key=lambda x: x["target_amount"], reverse=True)[:12]
        sorted_goals.reverse()
        labels = [f"{g['goal_id']}: {g['title'][:22]}" for g in sorted_goals]
        targets = [g["target_amount"] for g in sorted_goals]
        saved_vals = [g["current_amount"] for g in sorted_goals]
        status_colors = {
            "Completed": "#10b981",
            "On Track": "#3b82f6",
            "Behind Schedule": "#f59e0b",
            "At Risk": "#f97316",
            "Overdue": "#ef4444",
        }
        bar_colors = [status_colors.get(g["status"], "#3b82f6") for g in sorted_goals]

        fig, ax = plt.subplots(figsize=(10, 6), dpi=140)
        y_pos = range(len(labels))
        ax.barh(y_pos, targets, color="#e2e8f0", edgecolor="#94a3b8", height=0.62, label="Target Amount ($)")
        ax.barh(y_pos, saved_vals, color=bar_colors, height=0.42, label="Current Saved ($)")
        ax.set_yticks(list(y_pos))
        ax.set_yticklabels(labels, fontsize=9)
        ax.set_xlabel("Amount (USD $)", fontsize=10, fontweight="bold")
        ax.set_title("Savings Goals: Current Progress vs. Target (Top 12 by Target)", fontsize=12, fontweight="bold", pad=12)
        ax.grid(axis="x", linestyle="--", alpha=0.4)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        for idx, g in enumerate(sorted_goals):
            max_x = max(g["target_amount"], g["current_amount"])
            ax.text(max_x * 1.01, idx, f"{g['progress_pct']:.0f}% ({g['status']})", va="center", fontsize=8, color="#1e293b")

        ax.set_xlim(0, max(targets + saved_vals) * 1.25 if targets else 100)
        ax.legend(loc="lower right")
        plt.tight_layout()
        chart1_path = os.path.join(self.export_dir, f"{prefix}_goal_progress_{ts}.png")
        fig.savefig(chart1_path)
        plt.close(fig)
        saved_files.append(chart1_path)

        # --- Chart 2: Cumulative Savings & Monthly Deposit Trend ---
        trend = summary["monthly_trend"]
        if trend:
            months = [item[0] for item in trend]
            monthly_vols = [item[1] for item in trend]
            cum_vols = [item[2] for item in trend]

            fig, ax1 = plt.subplots(figsize=(10, 5), dpi=140)
            ax1.bar(months, monthly_vols, color="#93c5fd", alpha=0.75, label="Monthly Deposits ($)")
            ax1.set_ylabel("Monthly Deposits ($)", color="#1d4ed8", fontweight="bold")
            ax1.tick_params(axis="x", rotation=45)
            ax1.grid(axis="y", linestyle="--", alpha=0.35)

            ax2 = ax1.twinx()
            ax2.plot(months, cum_vols, color="#059669", marker="o", linewidth=2.5, label="Cumulative Savings ($)")
            ax2.set_ylabel("Cumulative Savings ($)", color="#059669", fontweight="bold")

            plt.title("Monthly Deposit Activity & Cumulative Savings Growth", fontsize=12, fontweight="bold", pad=12)
            fig.tight_layout()
            chart2_path = os.path.join(self.export_dir, f"{prefix}_savings_trend_{ts}.png")
            fig.savefig(chart2_path)
            plt.close(fig)
            saved_files.append(chart2_path)

        # --- Chart 3: Category Savings Distribution ---
        cat_stats = summary["category_stats"]
        if cat_stats:
            cats = list(cat_stats.keys())
            cat_saved = [cat_stats[c]["saved"] for c in cats]
            if sum(cat_saved) > 0:
                fig, ax = plt.subplots(figsize=(8, 6), dpi=140)
                palette = ["#2563eb", "#10b981", "#f59e0b", "#8b5cf6", "#ec4899", "#14b8a6", "#f97316", "#64748b", "#06b6d4", "#84cc16"]
                ax.pie(
                    cat_saved,
                    labels=cats,
                    autopct="%1.1f%%",
                    startangle=140,
                    pctdistance=0.78,
                    colors=palette[: len(cats)],
                    textprops={"fontsize": 9},
                )
                centre_circle = plt.Circle((0, 0), 0.52, fc="white")
                ax.add_artist(centre_circle)
                ax.set_title("Saved Capital Distribution by Category", fontsize=12, fontweight="bold", pad=12)
                plt.tight_layout()
                chart3_path = os.path.join(self.export_dir, f"{prefix}_category_dist_{ts}.png")
                fig.savefig(chart3_path)
                plt.close(fig)
                saved_files.append(chart3_path)

        return saved_files, None
