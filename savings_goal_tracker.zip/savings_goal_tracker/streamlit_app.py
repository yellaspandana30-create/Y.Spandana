"""
Modern Streamlit Web Interface for Savings Goal Tracker
GreenFuture Hack | Project #13
"""

import os
import tempfile
from datetime import date
import pandas as pd
import streamlit as st

from src.models import VALID_CATEGORIES, VALID_PRIORITIES
from src.validators import ValidationError
from src.engine import SavingsTrackerEngine
from src.analytics import AnalyticsEngine
from src.exporter import ReportExporterAndImporter

st.set_page_config(
    page_title="Savings Goal Tracker | GreenFuture Hack",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .block-container { padding-top: 1.5rem; padding-bottom: 2rem; }
    div[data-testid="stMetric"] {
        background-color: rgba(240, 244, 248, 0.55);
        border: 1px solid rgba(148, 163, 184, 0.25);
        padding: 14px 18px;
        border-radius: 10px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


def get_services():
    engine = SavingsTrackerEngine()
    analytics = AnalyticsEngine(engine)
    io_mgr = ReportExporterAndImporter(engine, analytics)
    return engine, analytics, io_mgr


engine, analytics, io_mgr = get_services()
summary = analytics.generate_executive_summary()
alerts = engine.evaluate_threshold_warnings()

# --- Sidebar: Quick Actions & System Status ---
with st.sidebar:
    st.title("💰 Savings Tracker")
    st.caption("GreenFuture Hack — Project #13")
    st.divider()

    st.subheader("System Health & Persistence")
    st.success(f"Synced: {summary['total_goals']} Goals | {summary['total_deposits_count']} Deposits")
    st.caption("Storage: `data/savings_data.json` & `data/savings_records.csv`")

    if st.button("🔄 Reload Disk State", use_container_width=True):
        st.rerun()

    st.divider()
    st.subheader("Threshold Alerts")
    crit = sum(1 for a in alerts if a.severity == "CRITICAL")
    warn = sum(1 for a in alerts if a.severity == "WARNING")
    info = sum(1 for a in alerts if a.severity == "INFO")
    st.write(f"🔴 Critical (Overdue): **{crit}**")
    st.write(f"🟠 Warnings (At Risk/Behind): **{warn}**")
    st.write(f"🔵 Info / Anomalies: **{info}**")

# --- Header & Executive KPI Row ---
st.title("Savings Goal Tracker & Analytics Dashboard")
st.caption("Track targets, validate deposits, monitor schedule velocity, and export executive reports.")

k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("Total Target Capital", f"${summary['total_target']:,.2f}")
k2.metric("Total Saved", f"${summary['total_saved']:,.2f}", f"{summary['overall_completion_pct']:.1f}% funded")
k3.metric("Remaining Shortfall", f"${summary['total_remaining']:,.2f}")
k4.metric("Avg Deposit Size", f"${summary['avg_deposit']:,.2f}", f"{summary['total_deposits_count']} deposits")
k5.metric("Active Warnings", f"{summary['alert_count']}", f"{crit} critical", delta_color="inverse")

st.divider()

# --- Navigation Tabs ---
tab_overview, tab_manage, tab_analytics, tab_export_import = st.tabs([
    "📊 Goals & Progress",
    "➕ Add Goal & Record Deposit",
    "📈 Visual Analytics & Alerts",
    "📤 Export Reports & Bulk CSV Import",
])

# === TAB 1: Goals & Search/Filter ===
with tab_overview:
    f1, f2, f3, f4 = st.columns([2, 1.2, 1.2, 1])
    search_kw = f1.text_input("🔍 Search by Goal Title, ID, or Notes", placeholder="e.g., Emergency, Solar, GOAL-101...")
    sel_cat = f2.selectbox("Category", ["All"] + VALID_CATEGORIES)
    sel_status = f3.selectbox("Status", ["All", "On Track", "Behind Schedule", "At Risk", "Overdue", "Completed"])
    sel_prio = f4.selectbox("Priority", ["All"] + VALID_PRIORITIES)

    filtered_goals = engine.search_goals(keyword=search_kw, category=sel_cat, status=sel_status, priority=sel_prio)
    st.write(f"Showing **{len(filtered_goals)}** matching savings goal(s)")

    if filtered_goals:
        df_goals = pd.DataFrame(filtered_goals)
        display_cols = [
            "goal_id", "title", "category", "priority", "current_amount",
            "target_amount", "remaining_amount", "progress_pct", "deadline",
            "days_remaining", "required_monthly", "status"
        ]
        st.dataframe(
            df_goals[display_cols],
            use_container_width=True,
            hide_index=True,
            column_config={
                "goal_id": "ID",
                "title": "Goal Title",
                "category": "Category",
                "priority": "Priority",
                "current_amount": st.column_config.NumberColumn("Saved ($)", format="$%.2f"),
                "target_amount": st.column_config.NumberColumn("Target ($)", format="$%.2f"),
                "remaining_amount": st.column_config.NumberColumn("Remaining ($)", format="$%.2f"),
                "progress_pct": st.column_config.ProgressColumn("Progress", min_value=0, max_value=100, format="%.1f%%"),
                "deadline": "Deadline",
                "days_remaining": "Days Left",
                "required_monthly": st.column_config.NumberColumn("Req. Monthly", format="$%.2f"),
                "status": "Status",
            },
        )

        st.subheader("Deposit Ledger")
        goal_filter_tx = st.selectbox(
            "Filter deposits by Goal",
            ["All Goals"] + [f"{g['goal_id']} - {g['title']}" for g in filtered_goals],
        )
        tx_gid = None if goal_filter_tx == "All Goals" else goal_filter_tx.split(" - ")[0]
        txs = engine.get_goal_transactions(tx_gid)
        if txs:
            df_tx = pd.DataFrame([t.to_dict() for t in txs])
            st.dataframe(
                df_tx,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "transaction_id": "Tx ID",
                    "goal_id": "Goal ID",
                    "amount": st.column_config.NumberColumn("Amount ($)", format="$%.2f"),
                    "transaction_date": "Date",
                    "note": "Note",
                    "source": "Source",
                },
            )
    else:
        st.info("No goals match your current filter criteria.")

# === TAB 2: Add Goal, Record Deposit & Edit/Delete ===
with tab_manage:
    col_left, col_right = st.columns(2)

    with col_left:
        st.subheader("Create New Savings Goal")
        with st.form("create_goal_form", clear_on_submit=True):
            g_title = st.text_input("Goal Title *", placeholder="e.g., Home Solar Battery Upgrade")
            g_cat = st.selectbox("Category *", VALID_CATEGORIES)
            c_a, c_b = st.columns(2)
            g_target = c_a.number_input("Target Amount ($) *", min_value=1.0, value=2500.0, step=100.0)
            g_initial = c_b.number_input("Initial Deposit ($)", min_value=0.0, value=0.0, step=50.0)
            c_c, c_d = st.columns(2)
            g_deadline = c_c.date_input("Target Deadline *", value=date(2027, 6, 30))
            g_prio = c_d.selectbox("Priority", VALID_PRIORITIES, index=1)
            g_notes = st.text_input("Notes (optional)", placeholder="Milestone details or account info")

            submitted_goal = st.form_submit_button("💾 Save New Goal", type="primary", use_container_width=True)
            if submitted_goal:
                try:
                    new_goal, warnings = engine.add_goal(
                        title=g_title,
                        category=g_cat,
                        target_amount=g_target,
                        deadline=g_deadline.isoformat(),
                        initial_amount=g_initial,
                        priority=g_prio,
                        notes=g_notes,
                    )
                    st.success(f"Created goal **{new_goal.title}** (`{new_goal.goal_id}`)!")
                    for w in warnings:
                        st.warning(w)
                    st.rerun()
                except ValidationError as err:
                    st.error(f"Validation Error: {err}")

    with col_right:
        st.subheader("Record Savings Deposit")
        all_goals = engine.get_all_enriched_goals()
        if not all_goals:
            st.info("Create a savings goal first before logging deposits.")
        else:
            with st.form("record_deposit_form", clear_on_submit=True):
                goal_options = {f"{g['goal_id']} — {g['title']} (${g['current_amount']:,.2f} / ${g['target_amount']:,.2f})": g["goal_id"] for g in all_goals}
                selected_label = st.selectbox("Select Goal *", list(goal_options.keys()))
                d_amt = st.number_input("Deposit Amount ($) *", min_value=0.01, value=250.0, step=25.0)
                d_date = st.date_input("Deposit Date *", value=date.today())
                d_note = st.text_input("Note", placeholder="Monthly auto-transfer / bonus allocation")

                submitted_tx = st.form_submit_button("💵 Log Deposit", type="primary", use_container_width=True)
                if submitted_tx:
                    try:
                        gid = goal_options[selected_label]
                        tx, updated_goal, warnings = engine.record_deposit(
                            goal_id=gid,
                            amount=d_amt,
                            transaction_date=d_date.isoformat(),
                            note=d_note,
                            source="Streamlit GUI",
                        )
                        st.success(f"Logged deposit `{tx.transaction_id}` of **${tx.amount:,.2f}** to `{updated_goal.goal_id}`!")
                        for w in warnings:
                            st.warning(w)
                        st.rerun()
                    except ValidationError as err:
                        st.error(f"Validation Error: {err}")

        st.divider()
        st.subheader("Update or Delete Existing Goal")
        if all_goals:
            edit_map = {f"{g['goal_id']} — {g['title']}": g for g in all_goals}
            sel_edit = st.selectbox("Choose Goal to Modify", list(edit_map.keys()), key="edit_goal_sel")
            target_g = edit_map[sel_edit]
            ec1, ec2, ec3 = st.columns(3)
            upd_target = ec1.number_input("Target ($)", min_value=1.0, value=float(target_g["target_amount"]), key="upd_t")
            upd_deadline = ec2.date_input("Deadline", value=date.fromisoformat(target_g["deadline"]), key="upd_d")
            upd_prio = ec3.selectbox("Priority", VALID_PRIORITIES, index=VALID_PRIORITIES.index(target_g["priority"]), key="upd_p")

            b1, b2 = st.columns(2)
            if b1.button("Update Goal", use_container_width=True):
                try:
                    engine.update_goal(
                        target_g["goal_id"],
                        target_amount=upd_target,
                        deadline=upd_deadline.isoformat(),
                        priority=upd_prio,
                    )
                    st.success(f"Updated {target_g['goal_id']}!")
                    st.rerun()
                except ValidationError as err:
                    st.error(str(err))
            if b2.button("🗑️ Delete Goal", use_container_width=True):
                engine.delete_goal(target_g["goal_id"])
                st.warning(f"Deleted {target_g['goal_id']}.")
                st.rerun()

# === TAB 3: Visual Analytics & Threshold Alerts ===
with tab_analytics:
    st.subheader("Automated Threshold Warning Indicators")
    if not alerts:
        st.success("All savings goals are healthy and within scheduled thresholds.")
    else:
        for alert in alerts:
            if alert.severity == "CRITICAL":
                st.error(f"**[{alert.severity}] {alert.goal_id} — {alert.goal_title}:** {alert.message}")
            elif alert.severity == "WARNING":
                st.warning(f"**[{alert.severity}] {alert.goal_id} — {alert.goal_title}:** {alert.message}")
            else:
                st.info(f"**[{alert.severity}] {alert.goal_id} — {alert.goal_title}:** {alert.message}")

    st.divider()
    st.subheader("Matplotlib Executive Visuals")
    if st.button("🎨 Render & Save High-DPI Charts to exports/"):
        chart_paths, warn_msg = analytics.generate_charts()
        if warn_msg:
            st.warning(warn_msg)
        if chart_paths:
            cols = st.columns(len(chart_paths))
            for idx, cpath in enumerate(chart_paths):
                cols[idx].image(cpath, caption=os.path.basename(cpath), use_container_width=True)
    else:
        chart_paths, warn_msg = analytics.generate_charts(prefix="preview")
        if warn_msg:
            st.warning(warn_msg)
        elif chart_paths:
            c1, c2 = st.columns(2)
            c1.image(chart_paths[0], caption="Goal Progress vs. Target", use_container_width=True)
            if len(chart_paths) > 1:
                c2.image(chart_paths[1], caption="Monthly & Cumulative Savings Trend", use_container_width=True)
            if len(chart_paths) > 2:
                st.image(chart_paths[2], caption="Category Distribution", width=550)

# === TAB 4: Multi-Format Export & Bulk CSV Import ===
with tab_export_import:
    ex_col, im_col = st.columns(2)

    with ex_col:
        st.subheader("Multi-Format Executive Exports")
        st.write("Generate timestamped Markdown reports, plain-text compliance audit logs, and standardized CSV files.")
        if st.button("📦 Generate All Report Formats", type="primary"):
            paths = io_mgr.export_all_formats()
            st.success("All report formats generated in `exports/`!")
            with open(paths["markdown"], "rb") as f:
                st.download_button("⬇️ Download Markdown Report (.md)", f, file_name=os.path.basename(paths["markdown"]))
            with open(paths["audit_txt"], "rb") as f:
                st.download_button("⬇️ Download Plain-Text Audit Log (.txt)", f, file_name=os.path.basename(paths["audit_txt"]))
            with open(paths["csv"], "rb") as f:
                st.download_button("⬇️ Download Standardized CSV (.csv)", f, file_name=os.path.basename(paths["csv"]))

    with im_col:
        st.subheader("Bulk CSV Dataset Importer")
        st.write("Upload a CSV with columns: `title, category, target_amount, deadline` (optional: `goal_id, current_amount, priority, notes`).")
        uploaded = st.file_uploader("Upload Legacy Goals CSV", type=["csv"])
        if uploaded is not None:
            if st.button("📥 Validate & Import CSV", type="primary"):
                with tempfile.NamedTemporaryFile(delete=False, suffix=".csv") as tmp:
                    tmp.write(uploaded.getvalue())
                    tmp_path = tmp.name
                try:
                    res = io_mgr.bulk_import_goals_csv(tmp_path)
                    st.success(f"Imported **{res['imported_count']}** valid goal(s)!")
                    if res["failed_count"] > 0:
                        st.warning(f"Rejected **{res['failed_count']}** invalid row(s). Error log saved at `{res['error_log_path']}`.")
                        with st.expander("View Row-by-Row Validation Errors"):
                            for err_line in res["failed_details"]:
                                st.code(err_line)
                except Exception as exc:
                    st.error(f"Import failed: {exc}")
                finally:
                    if os.path.exists(tmp_path):
                        os.remove(tmp_path)
